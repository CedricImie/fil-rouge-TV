<?php

namespace MovieBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MovieBundle extends Bundle
{
}
