<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_d51257bde4841e8dea1e9f3632fbfa423f9e21bf31d8432f59692f3c6562b78e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9c1d18e4ae242a3b3cecf64685472c023b30eca373fc30e8032c7fdeb868f71 = $this->env->getExtension("native_profiler");
        $__internal_f9c1d18e4ae242a3b3cecf64685472c023b30eca373fc30e8032c7fdeb868f71->enter($__internal_f9c1d18e4ae242a3b3cecf64685472c023b30eca373fc30e8032c7fdeb868f71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f9c1d18e4ae242a3b3cecf64685472c023b30eca373fc30e8032c7fdeb868f71->leave($__internal_f9c1d18e4ae242a3b3cecf64685472c023b30eca373fc30e8032c7fdeb868f71_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d11131563ab87f9626c83c76a0cddd3591233ed33cf2234edd24b1c65e409ba8 = $this->env->getExtension("native_profiler");
        $__internal_d11131563ab87f9626c83c76a0cddd3591233ed33cf2234edd24b1c65e409ba8->enter($__internal_d11131563ab87f9626c83c76a0cddd3591233ed33cf2234edd24b1c65e409ba8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_d11131563ab87f9626c83c76a0cddd3591233ed33cf2234edd24b1c65e409ba8->leave($__internal_d11131563ab87f9626c83c76a0cddd3591233ed33cf2234edd24b1c65e409ba8_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
