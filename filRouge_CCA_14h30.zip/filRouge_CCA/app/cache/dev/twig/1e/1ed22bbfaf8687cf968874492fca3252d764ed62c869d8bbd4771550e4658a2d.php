<?php

/* FOSUserBundle:Resetting:checkEmail.html.twig */
class __TwigTemplate_1f78ea6e7cc02d91ea98351632b8cd99c5fd6e5d0a56520ec75b511fd7a19450 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_98acf24d27fa207d921ba4d40fbead49e5c079ede72a1be57d9f6aa7f8f47ea5 = $this->env->getExtension("native_profiler");
        $__internal_98acf24d27fa207d921ba4d40fbead49e5c079ede72a1be57d9f6aa7f8f47ea5->enter($__internal_98acf24d27fa207d921ba4d40fbead49e5c079ede72a1be57d9f6aa7f8f47ea5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_98acf24d27fa207d921ba4d40fbead49e5c079ede72a1be57d9f6aa7f8f47ea5->leave($__internal_98acf24d27fa207d921ba4d40fbead49e5c079ede72a1be57d9f6aa7f8f47ea5_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b42f536736eb315bfafcd2f5538666e86f9c93e8fa6ed3c9b25b2979f9c5ab49 = $this->env->getExtension("native_profiler");
        $__internal_b42f536736eb315bfafcd2f5538666e86f9c93e8fa6ed3c9b25b2979f9c5ab49->enter($__internal_b42f536736eb315bfafcd2f5538666e86f9c93e8fa6ed3c9b25b2979f9c5ab49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.check_email", array("%email%" => (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_b42f536736eb315bfafcd2f5538666e86f9c93e8fa6ed3c9b25b2979f9c5ab49->leave($__internal_b42f536736eb315bfafcd2f5538666e86f9c93e8fa6ed3c9b25b2979f9c5ab49_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>*/
/* {{ 'resetting.check_email'|trans({'%email%': email}) }}*/
/* </p>*/
/* {% endblock %}*/
/* */
