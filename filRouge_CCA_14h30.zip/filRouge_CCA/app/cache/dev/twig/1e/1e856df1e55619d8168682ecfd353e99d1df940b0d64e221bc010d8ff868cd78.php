<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_d022adc85de4bc388b12465807762c2cbba405c194b7f1e12e450db7c28090a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f62927798fe1272517f3eda361dc7733c54721c71f244fe03e9ff75a2bfdcf08 = $this->env->getExtension("native_profiler");
        $__internal_f62927798fe1272517f3eda361dc7733c54721c71f244fe03e9ff75a2bfdcf08->enter($__internal_f62927798fe1272517f3eda361dc7733c54721c71f244fe03e9ff75a2bfdcf08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f62927798fe1272517f3eda361dc7733c54721c71f244fe03e9ff75a2bfdcf08->leave($__internal_f62927798fe1272517f3eda361dc7733c54721c71f244fe03e9ff75a2bfdcf08_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b1d621fa2fa22a45341bf33aa91021ff01471558d13e03aa58d16aeb042f0e12 = $this->env->getExtension("native_profiler");
        $__internal_b1d621fa2fa22a45341bf33aa91021ff01471558d13e03aa58d16aeb042f0e12->enter($__internal_b1d621fa2fa22a45341bf33aa91021ff01471558d13e03aa58d16aeb042f0e12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_b1d621fa2fa22a45341bf33aa91021ff01471558d13e03aa58d16aeb042f0e12->leave($__internal_b1d621fa2fa22a45341bf33aa91021ff01471558d13e03aa58d16aeb042f0e12_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:request_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
