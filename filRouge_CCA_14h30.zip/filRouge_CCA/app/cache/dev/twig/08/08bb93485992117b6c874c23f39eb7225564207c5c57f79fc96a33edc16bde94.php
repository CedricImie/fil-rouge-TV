<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_9efce37d6e03167028ed4a061e4d16b78350ddca75b50bb7a371678e51e8f741 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05fe7d47b1e161273f610cbf2d08e2be009c6abe763ca892fc0e302e3a611d9e = $this->env->getExtension("native_profiler");
        $__internal_05fe7d47b1e161273f610cbf2d08e2be009c6abe763ca892fc0e302e3a611d9e->enter($__internal_05fe7d47b1e161273f610cbf2d08e2be009c6abe763ca892fc0e302e3a611d9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_05fe7d47b1e161273f610cbf2d08e2be009c6abe763ca892fc0e302e3a611d9e->leave($__internal_05fe7d47b1e161273f610cbf2d08e2be009c6abe763ca892fc0e302e3a611d9e_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_b384f9705ca57c5a83a50905eeda178e300dcf49ab7732865e900b91f07f3335 = $this->env->getExtension("native_profiler");
        $__internal_b384f9705ca57c5a83a50905eeda178e300dcf49ab7732865e900b91f07f3335->enter($__internal_b384f9705ca57c5a83a50905eeda178e300dcf49ab7732865e900b91f07f3335_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_b384f9705ca57c5a83a50905eeda178e300dcf49ab7732865e900b91f07f3335->leave($__internal_b384f9705ca57c5a83a50905eeda178e300dcf49ab7732865e900b91f07f3335_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
