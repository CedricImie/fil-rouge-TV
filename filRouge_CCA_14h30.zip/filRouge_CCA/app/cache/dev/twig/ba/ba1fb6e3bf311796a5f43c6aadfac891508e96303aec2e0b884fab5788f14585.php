<?php

/* series/new.html.twig */
class __TwigTemplate_c8fd707cbc7d3d9636c1a231feb6f6e0e246d725951e2505c8ca69b46845486b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "series/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dab9afb394797506fbe99ba10c200313bab3f094bdc427e058444cf6abac12d5 = $this->env->getExtension("native_profiler");
        $__internal_dab9afb394797506fbe99ba10c200313bab3f094bdc427e058444cf6abac12d5->enter($__internal_dab9afb394797506fbe99ba10c200313bab3f094bdc427e058444cf6abac12d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "series/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dab9afb394797506fbe99ba10c200313bab3f094bdc427e058444cf6abac12d5->leave($__internal_dab9afb394797506fbe99ba10c200313bab3f094bdc427e058444cf6abac12d5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_78048b29f3ce43cd91684e76056b8ea0437810fffd302a38dce97b7826a597d3 = $this->env->getExtension("native_profiler");
        $__internal_78048b29f3ce43cd91684e76056b8ea0437810fffd302a38dce97b7826a597d3->enter($__internal_78048b29f3ce43cd91684e76056b8ea0437810fffd302a38dce97b7826a597d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
<!-- *** Header *** -->
<div class=\"header\">
  <!-- *** Logo *** -->
  <div class=\"row-H1\">
    <div class=\"logo\">
      <a href=\"http://127.0.0.1:8000\"><img src=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("/images/Logo.jpg"), "html", null, true);
        echo "\" alt=\"Logo du site\" /></a>
    </div>
    <!-- *** Login *** -->
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-2\">
      <div class=\"form-group form-group-sm\">
        <div class=\"login\">
          <input class=\"form-control\" type=\"text\" name=\"login\" placeholder=\"Identifiant\">
        </div>
        <div class=\"password\">
          <input class=\"form-control\" type=\"text\" name=\"password\" placeholder=\"Mot de passe\">
        </div>
      </div>
      <div class=\"btnConnInsc\">
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnConnexion\">Connexion</button>
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnSub\">Inscription</button>
      </div>
    </div>
  </div>
  <!-- *** Language *** -->
  <div class=\"row-H2\">
    <div class=\"col-md-1\">
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnFr\">Fr</button>
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnEn\">En</button>
    </div>
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-1\"></div>
  </div>
</div>
<!-- *** Main *** -->
    <h1>Series creation</h1>

    ";
        // line 42
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 43
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 45
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 49
        echo $this->env->getExtension('routing')->getPath("series_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
<!-- *** Footer *** -->
<div class=\"footer\">
  <div class=\"row-F1\"></div>
  <div class=\"row-F2\">
    <p>Imie</p>
  </div>
  <div class=\"row-F3\"></div>
</div>
";
        
        $__internal_78048b29f3ce43cd91684e76056b8ea0437810fffd302a38dce97b7826a597d3->leave($__internal_78048b29f3ce43cd91684e76056b8ea0437810fffd302a38dce97b7826a597d3_prof);

    }

    public function getTemplateName()
    {
        return "series/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 49,  92 => 45,  87 => 43,  83 => 42,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/* */
/* <!-- *** Header *** -->*/
/* <div class="header">*/
/*   <!-- *** Logo *** -->*/
/*   <div class="row-H1">*/
/*     <div class="logo">*/
/*       <a href="http://127.0.0.1:8000"><img src="{{ asset ('/images/Logo.jpg') }}" alt="Logo du site" /></a>*/
/*     </div>*/
/*     <!-- *** Login *** -->*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-2">*/
/*       <div class="form-group form-group-sm">*/
/*         <div class="login">*/
/*           <input class="form-control" type="text" name="login" placeholder="Identifiant">*/
/*         </div>*/
/*         <div class="password">*/
/*           <input class="form-control" type="text" name="password" placeholder="Mot de passe">*/
/*         </div>*/
/*       </div>*/
/*       <div class="btnConnInsc">*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnConnexion">Connexion</button>*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnSub">Inscription</button>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/*   <!-- *** Language *** -->*/
/*   <div class="row-H2">*/
/*     <div class="col-md-1">*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnFr">Fr</button>*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnEn">En</button>*/
/*     </div>*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-1"></div>*/
/*   </div>*/
/* </div>*/
/* <!-- *** Main *** -->*/
/*     <h1>Series creation</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Create" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('series_index') }}">Back to the list</a>*/
/*         </li>*/
/*     </ul>*/
/* <!-- *** Footer *** -->*/
/* <div class="footer">*/
/*   <div class="row-F1"></div>*/
/*   <div class="row-F2">*/
/*     <p>Imie</p>*/
/*   </div>*/
/*   <div class="row-F3"></div>*/
/* </div>*/
/* {% endblock %}*/
/* */
