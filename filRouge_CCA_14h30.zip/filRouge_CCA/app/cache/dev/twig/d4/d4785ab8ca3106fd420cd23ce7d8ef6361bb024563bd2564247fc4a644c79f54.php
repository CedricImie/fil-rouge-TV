<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_a87ac3edb72ca6e4a367f4eedc8f6b1cd2c6b1d199849f9cf859ed5213340878 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10c314d2c246f877e72469652426385a5414eb1578523a6d7c8527c70912c8dc = $this->env->getExtension("native_profiler");
        $__internal_10c314d2c246f877e72469652426385a5414eb1578523a6d7c8527c70912c8dc->enter($__internal_10c314d2c246f877e72469652426385a5414eb1578523a6d7c8527c70912c8dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_10c314d2c246f877e72469652426385a5414eb1578523a6d7c8527c70912c8dc->leave($__internal_10c314d2c246f877e72469652426385a5414eb1578523a6d7c8527c70912c8dc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
