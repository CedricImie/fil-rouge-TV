<?php

/* :acteurs:edit.html.twig */
class __TwigTemplate_ce3c1f42d7f3a7a2297d29ff3e1a93b923f946fde36ebb7e9437f292f30168ed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":acteurs:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6514d5002cd3ed168927a564250c6d43131ca23638b5821003d6277edf2f440c = $this->env->getExtension("native_profiler");
        $__internal_6514d5002cd3ed168927a564250c6d43131ca23638b5821003d6277edf2f440c->enter($__internal_6514d5002cd3ed168927a564250c6d43131ca23638b5821003d6277edf2f440c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":acteurs:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6514d5002cd3ed168927a564250c6d43131ca23638b5821003d6277edf2f440c->leave($__internal_6514d5002cd3ed168927a564250c6d43131ca23638b5821003d6277edf2f440c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4167d2481e71e9392f45b41984c872f57231ee02e87f0ede8e0b06037315efbc = $this->env->getExtension("native_profiler");
        $__internal_4167d2481e71e9392f45b41984c872f57231ee02e87f0ede8e0b06037315efbc->enter($__internal_4167d2481e71e9392f45b41984c872f57231ee02e87f0ede8e0b06037315efbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Acteurs edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("acteurs_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_4167d2481e71e9392f45b41984c872f57231ee02e87f0ede8e0b06037315efbc->leave($__internal_4167d2481e71e9392f45b41984c872f57231ee02e87f0ede8e0b06037315efbc_prof);

    }

    public function getTemplateName()
    {
        return ":acteurs:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Acteurs edit</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Edit" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('acteurs_index') }}">Back to the list</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Delete">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
