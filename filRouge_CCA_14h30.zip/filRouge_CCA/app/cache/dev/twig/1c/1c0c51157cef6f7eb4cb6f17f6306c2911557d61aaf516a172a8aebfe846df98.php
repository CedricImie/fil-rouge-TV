<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_e3d89adbac7e74aedb389a069506a18baf6cf1455fa5e433a882f68157bf9ddc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f42aab1a90abbcb18aa69c31f3f48f2f0606ab8945cf198e731ef7c06aa4c010 = $this->env->getExtension("native_profiler");
        $__internal_f42aab1a90abbcb18aa69c31f3f48f2f0606ab8945cf198e731ef7c06aa4c010->enter($__internal_f42aab1a90abbcb18aa69c31f3f48f2f0606ab8945cf198e731ef7c06aa4c010_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f42aab1a90abbcb18aa69c31f3f48f2f0606ab8945cf198e731ef7c06aa4c010->leave($__internal_f42aab1a90abbcb18aa69c31f3f48f2f0606ab8945cf198e731ef7c06aa4c010_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a6c222bafcc65d55e09c0397a248ae6e11967bac97021329f43f29272af8a77d = $this->env->getExtension("native_profiler");
        $__internal_a6c222bafcc65d55e09c0397a248ae6e11967bac97021329f43f29272af8a77d->enter($__internal_a6c222bafcc65d55e09c0397a248ae6e11967bac97021329f43f29272af8a77d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_a6c222bafcc65d55e09c0397a248ae6e11967bac97021329f43f29272af8a77d->leave($__internal_a6c222bafcc65d55e09c0397a248ae6e11967bac97021329f43f29272af8a77d_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:list_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
