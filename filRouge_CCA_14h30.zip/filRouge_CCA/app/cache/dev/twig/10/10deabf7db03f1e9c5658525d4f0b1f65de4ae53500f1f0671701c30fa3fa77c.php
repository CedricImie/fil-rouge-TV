<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_29d538386de02ca6767926a87107bd606a9dca1e20186808579bbbed7ee4b1fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75e75ceed0e5d9493274e4f1f3dab60371ada26b35477c3a0906296cc63f443b = $this->env->getExtension("native_profiler");
        $__internal_75e75ceed0e5d9493274e4f1f3dab60371ada26b35477c3a0906296cc63f443b->enter($__internal_75e75ceed0e5d9493274e4f1f3dab60371ada26b35477c3a0906296cc63f443b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_75e75ceed0e5d9493274e4f1f3dab60371ada26b35477c3a0906296cc63f443b->leave($__internal_75e75ceed0e5d9493274e4f1f3dab60371ada26b35477c3a0906296cc63f443b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
