<?php

/* FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_9d019450ec0c4d9beb42d18c6b6ad1d545f31f29909a31cb7a66172cdda5f0d5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_054243a6cf62136f58bfd0a36d32a72bb987019f145769d1e461105cae36838f = $this->env->getExtension("native_profiler");
        $__internal_054243a6cf62136f58bfd0a36d32a72bb987019f145769d1e461105cae36838f->enter($__internal_054243a6cf62136f58bfd0a36d32a72bb987019f145769d1e461105cae36838f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_054243a6cf62136f58bfd0a36d32a72bb987019f145769d1e461105cae36838f->leave($__internal_054243a6cf62136f58bfd0a36d32a72bb987019f145769d1e461105cae36838f_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_cd592e34e2f37a7f802d9fdd69241091d73512750f391ffb5c41b745618554e3 = $this->env->getExtension("native_profiler");
        $__internal_cd592e34e2f37a7f802d9fdd69241091d73512750f391ffb5c41b745618554e3->enter($__internal_cd592e34e2f37a7f802d9fdd69241091d73512750f391ffb5c41b745618554e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_cd592e34e2f37a7f802d9fdd69241091d73512750f391ffb5c41b745618554e3->leave($__internal_cd592e34e2f37a7f802d9fdd69241091d73512750f391ffb5c41b745618554e3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
