<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_82acea55af10affe43507831d3d45cac52e46a05a1b9718f49f973daa30ce193 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_72c09e34d3f67aab754dd1ce449d985727900893b7c642a2eb16bfb0d58c5264 = $this->env->getExtension("native_profiler");
        $__internal_72c09e34d3f67aab754dd1ce449d985727900893b7c642a2eb16bfb0d58c5264->enter($__internal_72c09e34d3f67aab754dd1ce449d985727900893b7c642a2eb16bfb0d58c5264_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_72c09e34d3f67aab754dd1ce449d985727900893b7c642a2eb16bfb0d58c5264->leave($__internal_72c09e34d3f67aab754dd1ce449d985727900893b7c642a2eb16bfb0d58c5264_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */
