<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_489655598c9436edc504b233113b94713bc6f8d1194a847a98deff43d2b14b7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fefd2e27c2f7c066451741ede2ab18b7750a2a50ac402e9b0b95b50df5e0890a = $this->env->getExtension("native_profiler");
        $__internal_fefd2e27c2f7c066451741ede2ab18b7750a2a50ac402e9b0b95b50df5e0890a->enter($__internal_fefd2e27c2f7c066451741ede2ab18b7750a2a50ac402e9b0b95b50df5e0890a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_fefd2e27c2f7c066451741ede2ab18b7750a2a50ac402e9b0b95b50df5e0890a->leave($__internal_fefd2e27c2f7c066451741ede2ab18b7750a2a50ac402e9b0b95b50df5e0890a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
