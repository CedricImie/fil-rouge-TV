<?php

/* :realisateurs:new.html.twig */
class __TwigTemplate_fb46a6077cbc2a663e7db01ad8b4a6a8ced17c99e1a9f51f357714a8446b5395 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":realisateurs:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a515aa2c1e63501c54a603263ead42265307f2ec6ab5eb579d1eb64e32f07b5 = $this->env->getExtension("native_profiler");
        $__internal_3a515aa2c1e63501c54a603263ead42265307f2ec6ab5eb579d1eb64e32f07b5->enter($__internal_3a515aa2c1e63501c54a603263ead42265307f2ec6ab5eb579d1eb64e32f07b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":realisateurs:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3a515aa2c1e63501c54a603263ead42265307f2ec6ab5eb579d1eb64e32f07b5->leave($__internal_3a515aa2c1e63501c54a603263ead42265307f2ec6ab5eb579d1eb64e32f07b5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0d332c8c19165455a1070b0e842f4560fd4e26e3da3849e60dcbc7e11c7da31a = $this->env->getExtension("native_profiler");
        $__internal_0d332c8c19165455a1070b0e842f4560fd4e26e3da3849e60dcbc7e11c7da31a->enter($__internal_0d332c8c19165455a1070b0e842f4560fd4e26e3da3849e60dcbc7e11c7da31a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Realisateurs creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("realisateurs_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_0d332c8c19165455a1070b0e842f4560fd4e26e3da3849e60dcbc7e11c7da31a->leave($__internal_0d332c8c19165455a1070b0e842f4560fd4e26e3da3849e60dcbc7e11c7da31a_prof);

    }

    public function getTemplateName()
    {
        return ":realisateurs:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Realisateurs creation</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Create" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('realisateurs_index') }}">Back to the list</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
