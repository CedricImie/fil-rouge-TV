<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_451d0e4ea7ad5ee34a42f8fd86dbab7c314e28f332c32a5fb9c6806bfde9a1fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29a34215febcc1ab7ce37ffd55cf169c62b59063c16b26bb939f54f203c80b65 = $this->env->getExtension("native_profiler");
        $__internal_29a34215febcc1ab7ce37ffd55cf169c62b59063c16b26bb939f54f203c80b65->enter($__internal_29a34215febcc1ab7ce37ffd55cf169c62b59063c16b26bb939f54f203c80b65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_29a34215febcc1ab7ce37ffd55cf169c62b59063c16b26bb939f54f203c80b65->leave($__internal_29a34215febcc1ab7ce37ffd55cf169c62b59063c16b26bb939f54f203c80b65_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
