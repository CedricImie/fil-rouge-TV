<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_25603827feb34cdd21e30509c5345cbf76b4430f1a02449e845c7bb53fec72f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_24e2bc6f0d35a5804d2a87eb17dcacae9145dfa91c6df24670fb8fbc4d36327b = $this->env->getExtension("native_profiler");
        $__internal_24e2bc6f0d35a5804d2a87eb17dcacae9145dfa91c6df24670fb8fbc4d36327b->enter($__internal_24e2bc6f0d35a5804d2a87eb17dcacae9145dfa91c6df24670fb8fbc4d36327b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_24e2bc6f0d35a5804d2a87eb17dcacae9145dfa91c6df24670fb8fbc4d36327b->leave($__internal_24e2bc6f0d35a5804d2a87eb17dcacae9145dfa91c6df24670fb8fbc4d36327b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
