<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_b671cd6d9fbc4f6d6d6070889451812d0f8ba7620df55c90f8e3d3fc2802aa27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9dedf060eda65168d9f8317845337ab64f345f92cf139159f9903f145148300a = $this->env->getExtension("native_profiler");
        $__internal_9dedf060eda65168d9f8317845337ab64f345f92cf139159f9903f145148300a->enter($__internal_9dedf060eda65168d9f8317845337ab64f345f92cf139159f9903f145148300a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_9dedf060eda65168d9f8317845337ab64f345f92cf139159f9903f145148300a->leave($__internal_9dedf060eda65168d9f8317845337ab64f345f92cf139159f9903f145148300a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
