<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_19490e4c40ecacb63b179b56f64e2f4261f86e63d5546e6709a22cc908b348dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_01554908281224019ca77e42d909d6c8197a592109cf5ac18f58b6f9f0706ec1 = $this->env->getExtension("native_profiler");
        $__internal_01554908281224019ca77e42d909d6c8197a592109cf5ac18f58b6f9f0706ec1->enter($__internal_01554908281224019ca77e42d909d6c8197a592109cf5ac18f58b6f9f0706ec1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_01554908281224019ca77e42d909d6c8197a592109cf5ac18f58b6f9f0706ec1->leave($__internal_01554908281224019ca77e42d909d6c8197a592109cf5ac18f58b6f9f0706ec1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */
