<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_26151d203bc6345bc1baff323263ace447e2899cf877f29fc508b04012a975d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd1a73e743db6aef5b4f887a2686265b31a0da92e80051a90d41f9dbcaec6bba = $this->env->getExtension("native_profiler");
        $__internal_fd1a73e743db6aef5b4f887a2686265b31a0da92e80051a90d41f9dbcaec6bba->enter($__internal_fd1a73e743db6aef5b4f887a2686265b31a0da92e80051a90d41f9dbcaec6bba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_fd1a73e743db6aef5b4f887a2686265b31a0da92e80051a90d41f9dbcaec6bba->leave($__internal_fd1a73e743db6aef5b4f887a2686265b31a0da92e80051a90d41f9dbcaec6bba_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
