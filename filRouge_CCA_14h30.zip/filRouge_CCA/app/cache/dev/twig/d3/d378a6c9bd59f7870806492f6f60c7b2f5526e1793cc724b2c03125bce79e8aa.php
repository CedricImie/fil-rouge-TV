<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_18179a7789cc47acdf49794cfcacb61c74eb3891389a7f1be9411ca7b48bd355 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_512ffaffe95fb248c868af983eafc6b437270104ad9887c1facd01e5d8c6579c = $this->env->getExtension("native_profiler");
        $__internal_512ffaffe95fb248c868af983eafc6b437270104ad9887c1facd01e5d8c6579c->enter($__internal_512ffaffe95fb248c868af983eafc6b437270104ad9887c1facd01e5d8c6579c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_512ffaffe95fb248c868af983eafc6b437270104ad9887c1facd01e5d8c6579c->leave($__internal_512ffaffe95fb248c868af983eafc6b437270104ad9887c1facd01e5d8c6579c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
