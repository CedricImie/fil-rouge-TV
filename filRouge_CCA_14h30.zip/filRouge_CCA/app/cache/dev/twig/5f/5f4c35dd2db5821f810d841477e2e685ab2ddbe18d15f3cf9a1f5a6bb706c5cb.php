<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_83d5147c6840c27adeee8b32e3d94031270173b656dac19913751fb64e25d78a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b2203f22c0838dd34e8ccf4d934c460f4bae6e121c2d2aaf5b077918b3d9f5a = $this->env->getExtension("native_profiler");
        $__internal_9b2203f22c0838dd34e8ccf4d934c460f4bae6e121c2d2aaf5b077918b3d9f5a->enter($__internal_9b2203f22c0838dd34e8ccf4d934c460f4bae6e121c2d2aaf5b077918b3d9f5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_9b2203f22c0838dd34e8ccf4d934c460f4bae6e121c2d2aaf5b077918b3d9f5a->leave($__internal_9b2203f22c0838dd34e8ccf4d934c460f4bae6e121c2d2aaf5b077918b3d9f5a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo str_replace('{{ widget }}', $view['form']->block($form, 'form_widget_simple'), $money_pattern) ?>*/
/* */
