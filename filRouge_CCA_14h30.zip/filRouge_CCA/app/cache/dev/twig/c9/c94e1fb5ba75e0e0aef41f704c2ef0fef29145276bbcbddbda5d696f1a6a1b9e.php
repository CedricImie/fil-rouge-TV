<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_be88c6451f3a88bd82a012258e78d04868a932bb08991cae5c1870234050c09f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_668f48250b243a9097b086b1c04d47f8164c03960bba21fb03ec261b345bc67f = $this->env->getExtension("native_profiler");
        $__internal_668f48250b243a9097b086b1c04d47f8164c03960bba21fb03ec261b345bc67f->enter($__internal_668f48250b243a9097b086b1c04d47f8164c03960bba21fb03ec261b345bc67f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_668f48250b243a9097b086b1c04d47f8164c03960bba21fb03ec261b345bc67f->leave($__internal_668f48250b243a9097b086b1c04d47f8164c03960bba21fb03ec261b345bc67f_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_2826d133a85bbd3045da36fbcdb30259f4757a48717392fb02dda4970d0571f0 = $this->env->getExtension("native_profiler");
        $__internal_2826d133a85bbd3045da36fbcdb30259f4757a48717392fb02dda4970d0571f0->enter($__internal_2826d133a85bbd3045da36fbcdb30259f4757a48717392fb02dda4970d0571f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_2826d133a85bbd3045da36fbcdb30259f4757a48717392fb02dda4970d0571f0->leave($__internal_2826d133a85bbd3045da36fbcdb30259f4757a48717392fb02dda4970d0571f0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
