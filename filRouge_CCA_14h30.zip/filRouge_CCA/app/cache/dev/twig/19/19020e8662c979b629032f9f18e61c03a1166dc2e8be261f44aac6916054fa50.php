<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_139fc49e88a7d42270ab39fd53142baa31391b199dc1ba22cb275faad68d29e0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58f245720110058c914d321d19385f35ec44c45ba1591a089ac700ce3f3f4dca = $this->env->getExtension("native_profiler");
        $__internal_58f245720110058c914d321d19385f35ec44c45ba1591a089ac700ce3f3f4dca->enter($__internal_58f245720110058c914d321d19385f35ec44c45ba1591a089ac700ce3f3f4dca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_58f245720110058c914d321d19385f35ec44c45ba1591a089ac700ce3f3f4dca->leave($__internal_58f245720110058c914d321d19385f35ec44c45ba1591a089ac700ce3f3f4dca_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child) : ?>*/
/*     <?php echo $view['form']->row($child) ?>*/
/* <?php endforeach; ?>*/
/* */
