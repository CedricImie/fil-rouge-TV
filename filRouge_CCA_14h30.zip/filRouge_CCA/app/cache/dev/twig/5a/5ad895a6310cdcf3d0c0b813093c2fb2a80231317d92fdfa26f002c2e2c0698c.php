<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_262c74c64fdf01984b95ed36f9e6e7466ec0f2202b11ceffac0e1c2671e0af35 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4795427191d52124f6e00d9dea28f4eba7cc9c79d326d16ca45cb6022a094b1c = $this->env->getExtension("native_profiler");
        $__internal_4795427191d52124f6e00d9dea28f4eba7cc9c79d326d16ca45cb6022a094b1c->enter($__internal_4795427191d52124f6e00d9dea28f4eba7cc9c79d326d16ca45cb6022a094b1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_4795427191d52124f6e00d9dea28f4eba7cc9c79d326d16ca45cb6022a094b1c->leave($__internal_4795427191d52124f6e00d9dea28f4eba7cc9c79d326d16ca45cb6022a094b1c_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_a5202ed411c919c024cc7c301c7425004c9db757d509b5595f3030f0d4bbb0a9 = $this->env->getExtension("native_profiler");
        $__internal_a5202ed411c919c024cc7c301c7425004c9db757d509b5595f3030f0d4bbb0a9->enter($__internal_a5202ed411c919c024cc7c301c7425004c9db757d509b5595f3030f0d4bbb0a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        echo "
";
        
        $__internal_a5202ed411c919c024cc7c301c7425004c9db757d509b5595f3030f0d4bbb0a9->leave($__internal_a5202ed411c919c024cc7c301c7425004c9db757d509b5595f3030f0d4bbb0a9_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_b120710ccb078a9c225026bf693130871c5361a0e172631a68bcf4b404b6475a = $this->env->getExtension("native_profiler");
        $__internal_b120710ccb078a9c225026bf693130871c5361a0e172631a68bcf4b404b6475a->enter($__internal_b120710ccb078a9c225026bf693130871c5361a0e172631a68bcf4b404b6475a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_b120710ccb078a9c225026bf693130871c5361a0e172631a68bcf4b404b6475a->leave($__internal_b120710ccb078a9c225026bf693130871c5361a0e172631a68bcf4b404b6475a_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_e63ac5e13c2402b75585cdb7aabf0b8661be57e149926b7bf5e54cd655dc7b3a = $this->env->getExtension("native_profiler");
        $__internal_e63ac5e13c2402b75585cdb7aabf0b8661be57e149926b7bf5e54cd655dc7b3a->enter($__internal_e63ac5e13c2402b75585cdb7aabf0b8661be57e149926b7bf5e54cd655dc7b3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_e63ac5e13c2402b75585cdb7aabf0b8661be57e149926b7bf5e54cd655dc7b3a->leave($__internal_e63ac5e13c2402b75585cdb7aabf0b8661be57e149926b7bf5e54cd655dc7b3a_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.subject'|trans({'%username%': user.username}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
