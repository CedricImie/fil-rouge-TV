<?php

/* :saisons:new.html.twig */
class __TwigTemplate_a7a225b03fd0df01d6adfe6ff9c4dd2b5e5daf3c7f6a883612b67e582124923c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":saisons:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b6b6b4a2a15b95915a98dadf799219bddf5e253984dc48af89803fc25a3a277 = $this->env->getExtension("native_profiler");
        $__internal_7b6b6b4a2a15b95915a98dadf799219bddf5e253984dc48af89803fc25a3a277->enter($__internal_7b6b6b4a2a15b95915a98dadf799219bddf5e253984dc48af89803fc25a3a277_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":saisons:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7b6b6b4a2a15b95915a98dadf799219bddf5e253984dc48af89803fc25a3a277->leave($__internal_7b6b6b4a2a15b95915a98dadf799219bddf5e253984dc48af89803fc25a3a277_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0ab672fd6d1279026743306c98b983b0bbc4daf18178cf6ecb58aa5459b159be = $this->env->getExtension("native_profiler");
        $__internal_0ab672fd6d1279026743306c98b983b0bbc4daf18178cf6ecb58aa5459b159be->enter($__internal_0ab672fd6d1279026743306c98b983b0bbc4daf18178cf6ecb58aa5459b159be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Saisons creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("saisons_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_0ab672fd6d1279026743306c98b983b0bbc4daf18178cf6ecb58aa5459b159be->leave($__internal_0ab672fd6d1279026743306c98b983b0bbc4daf18178cf6ecb58aa5459b159be_prof);

    }

    public function getTemplateName()
    {
        return ":saisons:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Saisons creation</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Create" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('saisons_index') }}">Back to the list</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
