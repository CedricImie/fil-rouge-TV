<?php

/* :commentaires:new.html.twig */
class __TwigTemplate_2978118763ffdd70aa96b2c2aa6b4ea7d3a39ed78b26c4343e44f5713dc9259e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":commentaires:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d0f6e5110ee3640e0cb32ad8e65a519a2e2573c9956b801a7a2a8baf7f1da3ae = $this->env->getExtension("native_profiler");
        $__internal_d0f6e5110ee3640e0cb32ad8e65a519a2e2573c9956b801a7a2a8baf7f1da3ae->enter($__internal_d0f6e5110ee3640e0cb32ad8e65a519a2e2573c9956b801a7a2a8baf7f1da3ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":commentaires:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d0f6e5110ee3640e0cb32ad8e65a519a2e2573c9956b801a7a2a8baf7f1da3ae->leave($__internal_d0f6e5110ee3640e0cb32ad8e65a519a2e2573c9956b801a7a2a8baf7f1da3ae_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_b546319c9c8f91a40e4c95f8662856586622e840e5fbaee1f27fec37d671ce47 = $this->env->getExtension("native_profiler");
        $__internal_b546319c9c8f91a40e4c95f8662856586622e840e5fbaee1f27fec37d671ce47->enter($__internal_b546319c9c8f91a40e4c95f8662856586622e840e5fbaee1f27fec37d671ce47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Commentaires creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("commentaires_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_b546319c9c8f91a40e4c95f8662856586622e840e5fbaee1f27fec37d671ce47->leave($__internal_b546319c9c8f91a40e4c95f8662856586622e840e5fbaee1f27fec37d671ce47_prof);

    }

    public function getTemplateName()
    {
        return ":commentaires:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Commentaires creation</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Create" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('commentaires_index') }}">Back to the list</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
