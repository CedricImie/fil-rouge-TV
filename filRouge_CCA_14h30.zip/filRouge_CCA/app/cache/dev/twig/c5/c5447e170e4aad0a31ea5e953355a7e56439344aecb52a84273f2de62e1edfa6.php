<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_838148653d4762736fd362624a2e4546f5bb52e4ad574d9b46d3c5768c55d01f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_054641a3edd7bfb9b38cf4ec3f58341875b0378b238f88a4d7f5c89c0ed36da7 = $this->env->getExtension("native_profiler");
        $__internal_054641a3edd7bfb9b38cf4ec3f58341875b0378b238f88a4d7f5c89c0ed36da7->enter($__internal_054641a3edd7bfb9b38cf4ec3f58341875b0378b238f88a4d7f5c89c0ed36da7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_054641a3edd7bfb9b38cf4ec3f58341875b0378b238f88a4d7f5c89c0ed36da7->leave($__internal_054641a3edd7bfb9b38cf4ec3f58341875b0378b238f88a4d7f5c89c0ed36da7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
