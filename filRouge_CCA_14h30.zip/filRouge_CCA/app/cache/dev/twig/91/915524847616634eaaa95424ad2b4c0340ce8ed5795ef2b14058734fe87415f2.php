<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_a795b975fb187b3be597d3c78b2af4870389692aae0e2c1cb7e860d2d3d4f112 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e6f1168d9eaefb2d0c2a0239b74e8a8df78e760e505176a81c85b2392955527 = $this->env->getExtension("native_profiler");
        $__internal_3e6f1168d9eaefb2d0c2a0239b74e8a8df78e760e505176a81c85b2392955527->enter($__internal_3e6f1168d9eaefb2d0c2a0239b74e8a8df78e760e505176a81c85b2392955527_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_3e6f1168d9eaefb2d0c2a0239b74e8a8df78e760e505176a81c85b2392955527->leave($__internal_3e6f1168d9eaefb2d0c2a0239b74e8a8df78e760e505176a81c85b2392955527_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
