<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_b5a0e9610f7d2744400f22270b0af18261d34bf96772a83893d627ad8862be9b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5437bca7f2f913f0f8319f0cd2e5ceffa28612c8d620da68f35571e60e828c1 = $this->env->getExtension("native_profiler");
        $__internal_f5437bca7f2f913f0f8319f0cd2e5ceffa28612c8d620da68f35571e60e828c1->enter($__internal_f5437bca7f2f913f0f8319f0cd2e5ceffa28612c8d620da68f35571e60e828c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_f5437bca7f2f913f0f8319f0cd2e5ceffa28612c8d620da68f35571e60e828c1->leave($__internal_f5437bca7f2f913f0f8319f0cd2e5ceffa28612c8d620da68f35571e60e828c1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!$label) { $label = isset($label_format)*/
/*     ? strtr($label_format, array('%name%' => $name, '%id%' => $id))*/
/*     : $view['form']->humanize($name); } ?>*/
/* <button type="<?php echo isset($type) ? $view->escape($type) : 'button' ?>" <?php echo $view['form']->block($form, 'button_attributes') ?>><?php echo $view->escape(false !== $translation_domain ? $view['translator']->trans($label, array(), $translation_domain) : $label) ?></button>*/
/* */
