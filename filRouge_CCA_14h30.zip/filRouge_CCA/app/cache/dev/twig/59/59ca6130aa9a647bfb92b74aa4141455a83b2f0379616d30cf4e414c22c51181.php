<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_3f299a5274045c954b073454942672c0b1317c26ea7654021549a1978472e752 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3e3727e23cea2b7b22eb57802b0b79cfd6ac64f8b6d5e9210e304bdab0fd2c8d = $this->env->getExtension("native_profiler");
        $__internal_3e3727e23cea2b7b22eb57802b0b79cfd6ac64f8b6d5e9210e304bdab0fd2c8d->enter($__internal_3e3727e23cea2b7b22eb57802b0b79cfd6ac64f8b6d5e9210e304bdab0fd2c8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_3e3727e23cea2b7b22eb57802b0b79cfd6ac64f8b6d5e9210e304bdab0fd2c8d->leave($__internal_3e3727e23cea2b7b22eb57802b0b79cfd6ac64f8b6d5e9210e304bdab0fd2c8d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
