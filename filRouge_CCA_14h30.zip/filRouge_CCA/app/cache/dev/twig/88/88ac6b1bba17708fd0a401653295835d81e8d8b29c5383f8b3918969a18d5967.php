<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_382f9ddb79052e5be7d6a1cfc8c85386cf975d69f3a9c558c9da5f24922f7266 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0944eafc3583a662cd1758ed16bfe3c8431ff42fb92207c2730107f4dd4d404c = $this->env->getExtension("native_profiler");
        $__internal_0944eafc3583a662cd1758ed16bfe3c8431ff42fb92207c2730107f4dd4d404c->enter($__internal_0944eafc3583a662cd1758ed16bfe3c8431ff42fb92207c2730107f4dd4d404c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_0944eafc3583a662cd1758ed16bfe3c8431ff42fb92207c2730107f4dd4d404c->leave($__internal_0944eafc3583a662cd1758ed16bfe3c8431ff42fb92207c2730107f4dd4d404c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
