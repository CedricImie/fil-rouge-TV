<?php

/* FOSUserBundle:ChangePassword:changePassword.html.twig */
class __TwigTemplate_363490e798a38d08a2d46cc157dabad18937a1feecfefc9a28a61391735be663 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff1193137e8c2648101f4dacfbc4783b40faa98d2ed176377972a22c80ab0602 = $this->env->getExtension("native_profiler");
        $__internal_ff1193137e8c2648101f4dacfbc4783b40faa98d2ed176377972a22c80ab0602->enter($__internal_ff1193137e8c2648101f4dacfbc4783b40faa98d2ed176377972a22c80ab0602_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ff1193137e8c2648101f4dacfbc4783b40faa98d2ed176377972a22c80ab0602->leave($__internal_ff1193137e8c2648101f4dacfbc4783b40faa98d2ed176377972a22c80ab0602_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_598890022447a9d3f01561c4753ff7cb75be55b1130c38bf721c8debfad62a0e = $this->env->getExtension("native_profiler");
        $__internal_598890022447a9d3f01561c4753ff7cb75be55b1130c38bf721c8debfad62a0e->enter($__internal_598890022447a9d3f01561c4753ff7cb75be55b1130c38bf721c8debfad62a0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 4)->display($context);
        
        $__internal_598890022447a9d3f01561c4753ff7cb75be55b1130c38bf721c8debfad62a0e->leave($__internal_598890022447a9d3f01561c4753ff7cb75be55b1130c38bf721c8debfad62a0e_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:ChangePassword:changePassword_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
