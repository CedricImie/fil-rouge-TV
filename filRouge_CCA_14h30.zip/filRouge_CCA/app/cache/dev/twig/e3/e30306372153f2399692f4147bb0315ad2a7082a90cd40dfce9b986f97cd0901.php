<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_7c784cb281016a4504dad19ac4bc5c043efd0256311191302736d90474b4f1b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_67cb7182241db546e757d0bf70bef631ba34bfd14d26319ad497ca7a966309a4 = $this->env->getExtension("native_profiler");
        $__internal_67cb7182241db546e757d0bf70bef631ba34bfd14d26319ad497ca7a966309a4->enter($__internal_67cb7182241db546e757d0bf70bef631ba34bfd14d26319ad497ca7a966309a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_67cb7182241db546e757d0bf70bef631ba34bfd14d26319ad497ca7a966309a4->leave($__internal_67cb7182241db546e757d0bf70bef631ba34bfd14d26319ad497ca7a966309a4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
