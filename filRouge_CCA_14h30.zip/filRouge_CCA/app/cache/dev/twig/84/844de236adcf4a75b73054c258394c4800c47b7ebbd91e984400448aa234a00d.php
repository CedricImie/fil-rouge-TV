<?php

/* :realisateurs:index.html.twig */
class __TwigTemplate_2af2b1243a3824e288c907c2a340641bf1f67ac521a1683af86afb6c1186dbe0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":realisateurs:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c161be0092597848a920a155ccf2d7415ba1dc03f68424bb91e3f8b2eb407cec = $this->env->getExtension("native_profiler");
        $__internal_c161be0092597848a920a155ccf2d7415ba1dc03f68424bb91e3f8b2eb407cec->enter($__internal_c161be0092597848a920a155ccf2d7415ba1dc03f68424bb91e3f8b2eb407cec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":realisateurs:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c161be0092597848a920a155ccf2d7415ba1dc03f68424bb91e3f8b2eb407cec->leave($__internal_c161be0092597848a920a155ccf2d7415ba1dc03f68424bb91e3f8b2eb407cec_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6819e79b32be96612e951d2608668599fdc5778e2e4b5a73fb4344f98bae98d2 = $this->env->getExtension("native_profiler");
        $__internal_6819e79b32be96612e951d2608668599fdc5778e2e4b5a73fb4344f98bae98d2->enter($__internal_6819e79b32be96612e951d2608668599fdc5778e2e4b5a73fb4344f98bae98d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Realisateurs list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Nomrealisateur</th>
                <th>Prenomrealisateur</th>
                <th>Datenaissancerealisateur</th>
                <th>Biorealisateur</th>
                <th>Serierealisateur</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["realisateurs"]) ? $context["realisateurs"] : $this->getContext($context, "realisateurs")));
        foreach ($context['_seq'] as $context["_key"] => $context["realisateur"]) {
            // line 20
            echo "            <tr>
                <td><a href=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("realisateurs_show", array("id" => $this->getAttribute($context["realisateur"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["realisateur"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["realisateur"], "nomRealisateur", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["realisateur"], "prenomRealisateur", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 24
            if ($this->getAttribute($context["realisateur"], "dateNaissanceRealisateur", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["realisateur"], "dateNaissanceRealisateur", array()), "Y-m-d H:i:s"), "html", null, true);
            }
            echo "</td>
                <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["realisateur"], "bioRealisateur", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["realisateur"], "serieRealisateur", array()), "html", null, true);
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("realisateurs_show", array("id" => $this->getAttribute($context["realisateur"], "id", array()))), "html", null, true);
            echo "\">show</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("realisateurs_edit", array("id" => $this->getAttribute($context["realisateur"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['realisateur'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 44
        echo $this->env->getExtension('routing')->getPath("realisateurs_new");
        echo "\">Create a new entry</a>
        </li>
    </ul>
";
        
        $__internal_6819e79b32be96612e951d2608668599fdc5778e2e4b5a73fb4344f98bae98d2->leave($__internal_6819e79b32be96612e951d2608668599fdc5778e2e4b5a73fb4344f98bae98d2_prof);

    }

    public function getTemplateName()
    {
        return ":realisateurs:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 44,  113 => 39,  101 => 33,  95 => 30,  88 => 26,  84 => 25,  78 => 24,  74 => 23,  70 => 22,  64 => 21,  61 => 20,  57 => 19,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Realisateurs list</h1>*/
/* */
/*     <table>*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <th>Nomrealisateur</th>*/
/*                 <th>Prenomrealisateur</th>*/
/*                 <th>Datenaissancerealisateur</th>*/
/*                 <th>Biorealisateur</th>*/
/*                 <th>Serierealisateur</th>*/
/*                 <th>Actions</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for realisateur in realisateurs %}*/
/*             <tr>*/
/*                 <td><a href="{{ path('realisateurs_show', { 'id': realisateur.id }) }}">{{ realisateur.id }}</a></td>*/
/*                 <td>{{ realisateur.nomRealisateur }}</td>*/
/*                 <td>{{ realisateur.prenomRealisateur }}</td>*/
/*                 <td>{% if realisateur.dateNaissanceRealisateur %}{{ realisateur.dateNaissanceRealisateur|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*                 <td>{{ realisateur.bioRealisateur }}</td>*/
/*                 <td>{{ realisateur.serieRealisateur }}</td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('realisateurs_show', { 'id': realisateur.id }) }}">show</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('realisateurs_edit', { 'id': realisateur.id }) }}">edit</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('realisateurs_new') }}">Create a new entry</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
