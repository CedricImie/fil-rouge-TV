<?php

/* :saisons:edit.html.twig */
class __TwigTemplate_495acae8f2ce2a9a5229ff31ef1e6d999245af3a2635de9869e365164033f752 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":saisons:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69e5e52f8c17a47d5d5fac54a230b16e682d340580c68412bcf22662d39900ea = $this->env->getExtension("native_profiler");
        $__internal_69e5e52f8c17a47d5d5fac54a230b16e682d340580c68412bcf22662d39900ea->enter($__internal_69e5e52f8c17a47d5d5fac54a230b16e682d340580c68412bcf22662d39900ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":saisons:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_69e5e52f8c17a47d5d5fac54a230b16e682d340580c68412bcf22662d39900ea->leave($__internal_69e5e52f8c17a47d5d5fac54a230b16e682d340580c68412bcf22662d39900ea_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_78efee6589d09050e285b72665ce9d59574ba76f4b369e9a56c3f8809bbb072b = $this->env->getExtension("native_profiler");
        $__internal_78efee6589d09050e285b72665ce9d59574ba76f4b369e9a56c3f8809bbb072b->enter($__internal_78efee6589d09050e285b72665ce9d59574ba76f4b369e9a56c3f8809bbb072b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Saisons edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("saisons_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_78efee6589d09050e285b72665ce9d59574ba76f4b369e9a56c3f8809bbb072b->leave($__internal_78efee6589d09050e285b72665ce9d59574ba76f4b369e9a56c3f8809bbb072b_prof);

    }

    public function getTemplateName()
    {
        return ":saisons:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Saisons edit</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Edit" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('saisons_index') }}">Back to the list</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Delete">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
