<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_0651424c38f6e433e7ed0c717c4f907b113a19f6f7d562c6b1de87691c228742 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a65cdd11ba8c7db973a4fa7e987c579c97a4ac68e65fcc6e04035fbc48c48f6a = $this->env->getExtension("native_profiler");
        $__internal_a65cdd11ba8c7db973a4fa7e987c579c97a4ac68e65fcc6e04035fbc48c48f6a->enter($__internal_a65cdd11ba8c7db973a4fa7e987c579c97a4ac68e65fcc6e04035fbc48c48f6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_a65cdd11ba8c7db973a4fa7e987c579c97a4ac68e65fcc6e04035fbc48c48f6a->leave($__internal_a65cdd11ba8c7db973a4fa7e987c579c97a4ac68e65fcc6e04035fbc48c48f6a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
