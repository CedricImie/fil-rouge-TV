<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_4eef22da9fedbdbb15cf198cecaa72799372d2a497518bb987718827c2d2b229 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa38a8c3341f204ae0b4f7a7e152f174eccb3915bc6acebc91e9445d91e8b0b0 = $this->env->getExtension("native_profiler");
        $__internal_fa38a8c3341f204ae0b4f7a7e152f174eccb3915bc6acebc91e9445d91e8b0b0->enter($__internal_fa38a8c3341f204ae0b4f7a7e152f174eccb3915bc6acebc91e9445d91e8b0b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_fa38a8c3341f204ae0b4f7a7e152f174eccb3915bc6acebc91e9445d91e8b0b0->leave($__internal_fa38a8c3341f204ae0b4f7a7e152f174eccb3915bc6acebc91e9445d91e8b0b0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
