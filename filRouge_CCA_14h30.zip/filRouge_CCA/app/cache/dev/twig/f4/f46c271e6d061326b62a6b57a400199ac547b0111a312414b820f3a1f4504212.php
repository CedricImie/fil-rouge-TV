<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_e798f97d23a288843bd6c20071528fb2228809136741525f78c627afaaef3270 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d3f15af335b383b6cb577d1408d3b831c3c49db2df8f79a0a27a17b8c4945dd = $this->env->getExtension("native_profiler");
        $__internal_7d3f15af335b383b6cb577d1408d3b831c3c49db2df8f79a0a27a17b8c4945dd->enter($__internal_7d3f15af335b383b6cb577d1408d3b831c3c49db2df8f79a0a27a17b8c4945dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_7d3f15af335b383b6cb577d1408d3b831c3c49db2df8f79a0a27a17b8c4945dd->leave($__internal_7d3f15af335b383b6cb577d1408d3b831c3c49db2df8f79a0a27a17b8c4945dd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
