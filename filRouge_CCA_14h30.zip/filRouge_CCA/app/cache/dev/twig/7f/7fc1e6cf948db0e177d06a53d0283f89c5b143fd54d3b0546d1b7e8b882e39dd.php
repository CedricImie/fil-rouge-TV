<?php

/* series/show.html.twig */
class __TwigTemplate_0d0462d59d8780d6ff3f9c35c975b2730256d90a6ee9296fab9ba38751cd051a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "series/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5bde4584b642d78cd5212dd09c616d08c999a2515d6b0d65da74caefa804173b = $this->env->getExtension("native_profiler");
        $__internal_5bde4584b642d78cd5212dd09c616d08c999a2515d6b0d65da74caefa804173b->enter($__internal_5bde4584b642d78cd5212dd09c616d08c999a2515d6b0d65da74caefa804173b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "series/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5bde4584b642d78cd5212dd09c616d08c999a2515d6b0d65da74caefa804173b->leave($__internal_5bde4584b642d78cd5212dd09c616d08c999a2515d6b0d65da74caefa804173b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_356e6cb6929579c66b816cca69c33ea16966821af1f3942586926c8a09c09b17 = $this->env->getExtension("native_profiler");
        $__internal_356e6cb6929579c66b816cca69c33ea16966821af1f3942586926c8a09c09b17->enter($__internal_356e6cb6929579c66b816cca69c33ea16966821af1f3942586926c8a09c09b17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<!-- *** Header *** -->
<div class=\"header\">
  <!-- *** Logo *** -->
  <div class=\"row-H1\">
    <div class=\"logo\">
      <a href=\"http://127.0.0.1:8000\"><img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("/images/Logo.jpg"), "html", null, true);
        echo "\" alt=\"Logo du site\" /></a>
    </div>
    <!-- *** Login *** -->
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-2\">
      <div class=\"form-group form-group-sm\">
        <div class=\"login\">
          <input class=\"form-control\" type=\"text\" name=\"login\" placeholder=\"Identifiant\">
        </div>
        <div class=\"password\">
          <input class=\"form-control\" type=\"text\" name=\"password\" placeholder=\"Mot de passe\">
        </div>
      </div>
      <div class=\"btnConnInsc\">
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnConnexion\">Connexion</button>
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnSub\">Inscription</button>
      </div>
    </div>
  </div>
  <!-- *** Language *** -->
  <div class=\"row-H2\">
    <div class=\"col-md-1\">
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnFr\">Fr</button>
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnEn\">En</button>
    </div>
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-1\"></div>
  </div>
</div>
<!-- *** Main *** -->
    <h1>Series</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 45
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Nomserie</th>
                <td>";
        // line 49
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "nomSerie", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Posterserie</th>
                <td>";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "posterSerie", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Resumeserie</th>
                <td>";
        // line 57
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "resumeSerie", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Datecreationserie</th>
                <td>";
        // line 61
        if ($this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "dateCreationSerie", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "dateCreationSerie", array()), "Y-m-d H:i:s"), "html", null, true);
        }
        echo "</td>
            </tr>
            <tr>
                <th>Notemoyenneserie</th>
                <td>";
        // line 65
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "noteMoyenneSerie", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Nbabonneserie</th>
                <td>";
        // line 69
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "nbAbonneSerie", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Castingserie</th>
                <td>";
        // line 73
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "castingSerie", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Genreserie</th>
                <td>";
        // line 77
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "genreSerie", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Diffusionserie</th>
                <td>";
        // line 81
        if ($this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "diffusionSerie", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "diffusionSerie", array()), "Y-m-d H:i:s"), "html", null, true);
        }
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 88
        echo $this->env->getExtension('routing')->getPath("series_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 91
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("series_edit", array("id" => $this->getAttribute((isset($context["series"]) ? $context["series"] : $this->getContext($context, "series")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 94
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 96
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
<!-- *** Footer *** -->
<div class=\"footer\">
  <div class=\"row-F1\"></div>
  <div class=\"row-F2\">
    <p>Imie</p>
  </div>
  <div class=\"row-F3\"></div>
</div>
";
        
        $__internal_356e6cb6929579c66b816cca69c33ea16966821af1f3942586926c8a09c09b17->leave($__internal_356e6cb6929579c66b816cca69c33ea16966821af1f3942586926c8a09c09b17_prof);

    }

    public function getTemplateName()
    {
        return "series/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  180 => 96,  175 => 94,  169 => 91,  163 => 88,  151 => 81,  144 => 77,  137 => 73,  130 => 69,  123 => 65,  114 => 61,  107 => 57,  100 => 53,  93 => 49,  86 => 45,  47 => 9,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/* <!-- *** Header *** -->*/
/* <div class="header">*/
/*   <!-- *** Logo *** -->*/
/*   <div class="row-H1">*/
/*     <div class="logo">*/
/*       <a href="http://127.0.0.1:8000"><img src="{{ asset ('/images/Logo.jpg') }}" alt="Logo du site" /></a>*/
/*     </div>*/
/*     <!-- *** Login *** -->*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-2">*/
/*       <div class="form-group form-group-sm">*/
/*         <div class="login">*/
/*           <input class="form-control" type="text" name="login" placeholder="Identifiant">*/
/*         </div>*/
/*         <div class="password">*/
/*           <input class="form-control" type="text" name="password" placeholder="Mot de passe">*/
/*         </div>*/
/*       </div>*/
/*       <div class="btnConnInsc">*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnConnexion">Connexion</button>*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnSub">Inscription</button>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/*   <!-- *** Language *** -->*/
/*   <div class="row-H2">*/
/*     <div class="col-md-1">*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnFr">Fr</button>*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnEn">En</button>*/
/*     </div>*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-1"></div>*/
/*   </div>*/
/* </div>*/
/* <!-- *** Main *** -->*/
/*     <h1>Series</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ series.id }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Nomserie</th>*/
/*                 <td>{{ series.nomSerie }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Posterserie</th>*/
/*                 <td>{{ series.posterSerie }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Resumeserie</th>*/
/*                 <td>{{ series.resumeSerie }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Datecreationserie</th>*/
/*                 <td>{% if series.dateCreationSerie %}{{ series.dateCreationSerie|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Notemoyenneserie</th>*/
/*                 <td>{{ series.noteMoyenneSerie }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Nbabonneserie</th>*/
/*                 <td>{{ series.nbAbonneSerie }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Castingserie</th>*/
/*                 <td>{{ series.castingSerie }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Genreserie</th>*/
/*                 <td>{{ series.genreSerie }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Diffusionserie</th>*/
/*                 <td>{% if series.diffusionSerie %}{{ series.diffusionSerie|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('series_index') }}">Back to the list</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('series_edit', { 'id': series.id }) }}">Edit</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Delete">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* <!-- *** Footer *** -->*/
/* <div class="footer">*/
/*   <div class="row-F1"></div>*/
/*   <div class="row-F2">*/
/*     <p>Imie</p>*/
/*   </div>*/
/*   <div class="row-F3"></div>*/
/* </div>*/
/* {% endblock %}*/
/* */
