<?php

/* :moderateurs:new.html.twig */
class __TwigTemplate_1aca6916bf805913a59245540a06737ca91a83aee2a8676093117dc987bfc98a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":moderateurs:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2afcd8b71fd939a44797d2ab4d1594b4b0ae1acc9ed9510e463a98106f7990a2 = $this->env->getExtension("native_profiler");
        $__internal_2afcd8b71fd939a44797d2ab4d1594b4b0ae1acc9ed9510e463a98106f7990a2->enter($__internal_2afcd8b71fd939a44797d2ab4d1594b4b0ae1acc9ed9510e463a98106f7990a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":moderateurs:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2afcd8b71fd939a44797d2ab4d1594b4b0ae1acc9ed9510e463a98106f7990a2->leave($__internal_2afcd8b71fd939a44797d2ab4d1594b4b0ae1acc9ed9510e463a98106f7990a2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_87db4633fe9d04e928d63b7e8b398c6a41427a5b93506664be84006adc16a207 = $this->env->getExtension("native_profiler");
        $__internal_87db4633fe9d04e928d63b7e8b398c6a41427a5b93506664be84006adc16a207->enter($__internal_87db4633fe9d04e928d63b7e8b398c6a41427a5b93506664be84006adc16a207_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Moderateurs creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("moderateurs_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_87db4633fe9d04e928d63b7e8b398c6a41427a5b93506664be84006adc16a207->leave($__internal_87db4633fe9d04e928d63b7e8b398c6a41427a5b93506664be84006adc16a207_prof);

    }

    public function getTemplateName()
    {
        return ":moderateurs:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Moderateurs creation</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Create" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('moderateurs_index') }}">Back to the list</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
