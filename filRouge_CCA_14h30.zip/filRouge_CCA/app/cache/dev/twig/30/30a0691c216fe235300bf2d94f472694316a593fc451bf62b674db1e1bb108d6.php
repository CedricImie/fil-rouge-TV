<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_56acef76f9d970efe1cbbb5e283ea864153a87c983f02489f33368a5b3f90937 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d36dc3b320f6420825ab6ff30e53fda227dd2d8dc5e4cd19b628b86fb90ea929 = $this->env->getExtension("native_profiler");
        $__internal_d36dc3b320f6420825ab6ff30e53fda227dd2d8dc5e4cd19b628b86fb90ea929->enter($__internal_d36dc3b320f6420825ab6ff30e53fda227dd2d8dc5e4cd19b628b86fb90ea929_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_d36dc3b320f6420825ab6ff30e53fda227dd2d8dc5e4cd19b628b86fb90ea929->leave($__internal_d36dc3b320f6420825ab6ff30e53fda227dd2d8dc5e4cd19b628b86fb90ea929_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
