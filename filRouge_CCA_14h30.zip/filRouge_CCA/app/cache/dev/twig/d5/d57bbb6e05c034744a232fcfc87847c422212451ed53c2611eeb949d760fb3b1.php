<?php

/* :realisateurs:edit.html.twig */
class __TwigTemplate_cea4b6a4e05ddb1d65a49666912b6c48c1c5ac7913422f8dd7490a37ecefb76c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":realisateurs:edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_afaac3e622a1ad969b42b7f38b57cd11c7a1ceebc75c4e9d20bf1da9bd635363 = $this->env->getExtension("native_profiler");
        $__internal_afaac3e622a1ad969b42b7f38b57cd11c7a1ceebc75c4e9d20bf1da9bd635363->enter($__internal_afaac3e622a1ad969b42b7f38b57cd11c7a1ceebc75c4e9d20bf1da9bd635363_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":realisateurs:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_afaac3e622a1ad969b42b7f38b57cd11c7a1ceebc75c4e9d20bf1da9bd635363->leave($__internal_afaac3e622a1ad969b42b7f38b57cd11c7a1ceebc75c4e9d20bf1da9bd635363_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4b0b6a86127099a4a844cf3521f2fcf1d1486ccbf1c26cedffb71b8a040c2230 = $this->env->getExtension("native_profiler");
        $__internal_4b0b6a86127099a4a844cf3521f2fcf1d1486ccbf1c26cedffb71b8a040c2230->enter($__internal_4b0b6a86127099a4a844cf3521f2fcf1d1486ccbf1c26cedffb71b8a040c2230_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Realisateurs edit</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Edit\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["edit_form"]) ? $context["edit_form"] : $this->getContext($context, "edit_form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("realisateurs_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            ";
        // line 16
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 18
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_4b0b6a86127099a4a844cf3521f2fcf1d1486ccbf1c26cedffb71b8a040c2230->leave($__internal_4b0b6a86127099a4a844cf3521f2fcf1d1486ccbf1c26cedffb71b8a040c2230_prof);

    }

    public function getTemplateName()
    {
        return ":realisateurs:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  71 => 18,  66 => 16,  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Realisateurs edit</h1>*/
/* */
/*     {{ form_start(edit_form) }}*/
/*         {{ form_widget(edit_form) }}*/
/*         <input type="submit" value="Edit" />*/
/*     {{ form_end(edit_form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('realisateurs_index') }}">Back to the list</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Delete">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
