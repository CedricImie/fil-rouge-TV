<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_428c7ebbcc6f57dc647975f422419f592f16b4dc969cb4cbe5c2cddac75b0203 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0198b560a354317435e8a1dcff57f5ac804d442bb97cc6466dcbe0e1404119fb = $this->env->getExtension("native_profiler");
        $__internal_0198b560a354317435e8a1dcff57f5ac804d442bb97cc6466dcbe0e1404119fb->enter($__internal_0198b560a354317435e8a1dcff57f5ac804d442bb97cc6466dcbe0e1404119fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0198b560a354317435e8a1dcff57f5ac804d442bb97cc6466dcbe0e1404119fb->leave($__internal_0198b560a354317435e8a1dcff57f5ac804d442bb97cc6466dcbe0e1404119fb_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_30f9797dc998a35843c4a3d8f06a53b370bb18cced6e5ae175acede59ba009c0 = $this->env->getExtension("native_profiler");
        $__internal_30f9797dc998a35843c4a3d8f06a53b370bb18cced6e5ae175acede59ba009c0->enter($__internal_30f9797dc998a35843c4a3d8f06a53b370bb18cced6e5ae175acede59ba009c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_30f9797dc998a35843c4a3d8f06a53b370bb18cced6e5ae175acede59ba009c0->leave($__internal_30f9797dc998a35843c4a3d8f06a53b370bb18cced6e5ae175acede59ba009c0_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
