<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_e86c370cf7cfd6d3358e9744a7d00c43fba3dae43045f1b8c7d1abeb4c71185a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89ace13cb2ab37b670a5b35cb317d626f0e1eacbc767011efc00fc6044d9eabd = $this->env->getExtension("native_profiler");
        $__internal_89ace13cb2ab37b670a5b35cb317d626f0e1eacbc767011efc00fc6044d9eabd->enter($__internal_89ace13cb2ab37b670a5b35cb317d626f0e1eacbc767011efc00fc6044d9eabd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_89ace13cb2ab37b670a5b35cb317d626f0e1eacbc767011efc00fc6044d9eabd->leave($__internal_89ace13cb2ab37b670a5b35cb317d626f0e1eacbc767011efc00fc6044d9eabd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
