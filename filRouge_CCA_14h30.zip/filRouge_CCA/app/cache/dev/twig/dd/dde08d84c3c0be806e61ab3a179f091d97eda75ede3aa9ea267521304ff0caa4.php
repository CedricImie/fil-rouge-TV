<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_585aca937ff60e3a6183a8b4d5f9993f60cee386843296d1567cda8693e462a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_54b560e9abf830274c5f5be8a498a2f512663707f1b0e964eaebe8d5a9eb913b = $this->env->getExtension("native_profiler");
        $__internal_54b560e9abf830274c5f5be8a498a2f512663707f1b0e964eaebe8d5a9eb913b->enter($__internal_54b560e9abf830274c5f5be8a498a2f512663707f1b0e964eaebe8d5a9eb913b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_54b560e9abf830274c5f5be8a498a2f512663707f1b0e964eaebe8d5a9eb913b->leave($__internal_54b560e9abf830274c5f5be8a498a2f512663707f1b0e964eaebe8d5a9eb913b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 4,  22 => 1,);
    }
}
/* Oops! An Error Occurred*/
/* =======================*/
/* */
/* The server returned a "{{ status_code }} {{ status_text }}".*/
/* */
/* Something is broken. Please let us know what you were doing when this error occurred.*/
/* We will fix it as soon as possible. Sorry for any inconvenience caused.*/
/* */
