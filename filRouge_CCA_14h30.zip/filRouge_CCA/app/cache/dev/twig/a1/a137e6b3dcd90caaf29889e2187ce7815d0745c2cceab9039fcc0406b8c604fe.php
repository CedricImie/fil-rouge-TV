<?php

/* NurikabeStarRatingBundle:Form:fields.html.twig */
class __TwigTemplate_8f389b46989f59b0a45163c5fe8f03a95bbaa892f1da0dccad8437f5d684a06a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'star_rating_widget' => array($this, 'block_star_rating_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_334b6ed75ed3799a05768c84d14ee88378d2a249026740509fb98bb5b59eaa77 = $this->env->getExtension("native_profiler");
        $__internal_334b6ed75ed3799a05768c84d14ee88378d2a249026740509fb98bb5b59eaa77->enter($__internal_334b6ed75ed3799a05768c84d14ee88378d2a249026740509fb98bb5b59eaa77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NurikabeStarRatingBundle:Form:fields.html.twig"));

        // line 1
        $this->displayBlock('star_rating_widget', $context, $blocks);
        
        $__internal_334b6ed75ed3799a05768c84d14ee88378d2a249026740509fb98bb5b59eaa77->leave($__internal_334b6ed75ed3799a05768c84d14ee88378d2a249026740509fb98bb5b59eaa77_prof);

    }

    public function block_star_rating_widget($context, array $blocks = array())
    {
        $__internal_c97559c772852f135bb645fb9821d9a16c83f976ddcea7aba4e0651eac8a0b21 = $this->env->getExtension("native_profiler");
        $__internal_c97559c772852f135bb645fb9821d9a16c83f976ddcea7aba4e0651eac8a0b21->enter($__internal_c97559c772852f135bb645fb9821d9a16c83f976ddcea7aba4e0651eac8a0b21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "star_rating_widget"));

        // line 2
        echo "    ";
        ob_start();
        // line 3
        echo "        ";
        if ((isset($context["expanded"]) ? $context["expanded"] : $this->getContext($context, "expanded"))) {
            // line 4
            echo "            <div ";
            $this->displayBlock("widget_container_attributes", $context, $blocks);
            echo ">
                ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 6
                echo "                    ";
                // line 7
                echo "                    ";
                $context["starredClass"] = ("star" . (($this->getAttribute($this->getAttribute($context["child"], "vars", array()), "required", array())) ? (" required") : ("")));
                // line 8
                echo "                    ";
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'widget', array("attr" => array("class" => (isset($context["starredClass"]) ? $context["starredClass"] : $this->getContext($context, "starredClass")), "title" => $this->getAttribute($this->getAttribute($context["child"], "vars", array()), "label", array()))));
                echo "
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 10
            echo "            </div>
        ";
        } else {
            // line 12
            echo "            ";
            // line 13
            echo "            ";
            $this->displayBlock("choice_widget", $context, $blocks);
            echo "
        ";
        }
        // line 15
        echo "    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_c97559c772852f135bb645fb9821d9a16c83f976ddcea7aba4e0651eac8a0b21->leave($__internal_c97559c772852f135bb645fb9821d9a16c83f976ddcea7aba4e0651eac8a0b21_prof);

    }

    public function getTemplateName()
    {
        return "NurikabeStarRatingBundle:Form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  76 => 15,  70 => 13,  68 => 12,  64 => 10,  55 => 8,  52 => 7,  50 => 6,  46 => 5,  41 => 4,  38 => 3,  35 => 2,  23 => 1,);
    }
}
/* {% block star_rating_widget %}*/
/*     {% spaceless %}*/
/*         {% if expanded %}*/
/*             <div {{ block('widget_container_attributes') }}>*/
/*                 {% for child in form %}*/
/*                     {# Create class string with "star" appended #}*/
/*                     {% set starredClass = 'star' ~ (child.vars.required ? ' required') %}*/
/*                     {{ form_widget(child, {'attr': {'class': starredClass, 'title': child.vars.label}}) }}*/
/*                 {% endfor %}*/
/*             </div>*/
/*         {% else %}*/
/*             {# Let the choice widget render the select tag #}*/
/*             {{ block('choice_widget') }}*/
/*         {% endif %}*/
/*     {% endspaceless %}*/
/* {% endblock star_rating_widget %}*/
/* */
