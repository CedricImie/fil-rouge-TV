<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_2848e34f657bb2de64032f4e86acaa8c9265dde3db42223f77101835979f6987 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15f39a7cb8fc9e4bf4f1ecb8e48ca6060e1296f6414ad82436efe4c45a191e24 = $this->env->getExtension("native_profiler");
        $__internal_15f39a7cb8fc9e4bf4f1ecb8e48ca6060e1296f6414ad82436efe4c45a191e24->enter($__internal_15f39a7cb8fc9e4bf4f1ecb8e48ca6060e1296f6414ad82436efe4c45a191e24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_15f39a7cb8fc9e4bf4f1ecb8e48ca6060e1296f6414ad82436efe4c45a191e24->leave($__internal_15f39a7cb8fc9e4bf4f1ecb8e48ca6060e1296f6414ad82436efe4c45a191e24_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
