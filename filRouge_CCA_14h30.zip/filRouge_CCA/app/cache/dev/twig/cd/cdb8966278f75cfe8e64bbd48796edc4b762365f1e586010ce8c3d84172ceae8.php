<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_77579e253f043040e5d8185ed97e1547db124b2b3f0e6594bda3e1b3e9ea1bc9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_95b20b141923fa1b28dc44919bca6447f9b0666538499a54267f66ae64d97add = $this->env->getExtension("native_profiler");
        $__internal_95b20b141923fa1b28dc44919bca6447f9b0666538499a54267f66ae64d97add->enter($__internal_95b20b141923fa1b28dc44919bca6447f9b0666538499a54267f66ae64d97add_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_95b20b141923fa1b28dc44919bca6447f9b0666538499a54267f66ae64d97add->leave($__internal_95b20b141923fa1b28dc44919bca6447f9b0666538499a54267f66ae64d97add_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
