<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_391214c3d94d9f2d95d3a98a5b38114f2217a3d37d0d82313adae7250bf729e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_638d43a760c6f9a1d94872f257cfd5074a11bfc9097b1411db6d12f260ad3d3f = $this->env->getExtension("native_profiler");
        $__internal_638d43a760c6f9a1d94872f257cfd5074a11bfc9097b1411db6d12f260ad3d3f->enter($__internal_638d43a760c6f9a1d94872f257cfd5074a11bfc9097b1411db6d12f260ad3d3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_638d43a760c6f9a1d94872f257cfd5074a11bfc9097b1411db6d12f260ad3d3f->leave($__internal_638d43a760c6f9a1d94872f257cfd5074a11bfc9097b1411db6d12f260ad3d3f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
