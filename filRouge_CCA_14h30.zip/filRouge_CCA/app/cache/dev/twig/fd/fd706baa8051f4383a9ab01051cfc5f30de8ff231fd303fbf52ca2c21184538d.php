<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_09d46f8610eca0552d9ef7a6be8397cf26f1ba1f72f8a03a5c5d4871044a4fc3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c66b5ff8303f859974fd66cf12a1f534da15ca420777958528ccf713a2b9eb1 = $this->env->getExtension("native_profiler");
        $__internal_1c66b5ff8303f859974fd66cf12a1f534da15ca420777958528ccf713a2b9eb1->enter($__internal_1c66b5ff8303f859974fd66cf12a1f534da15ca420777958528ccf713a2b9eb1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_1c66b5ff8303f859974fd66cf12a1f534da15ca420777958528ccf713a2b9eb1->leave($__internal_1c66b5ff8303f859974fd66cf12a1f534da15ca420777958528ccf713a2b9eb1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
