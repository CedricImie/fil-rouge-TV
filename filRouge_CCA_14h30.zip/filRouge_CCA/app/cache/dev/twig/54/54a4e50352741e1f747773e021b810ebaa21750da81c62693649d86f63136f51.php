<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_e8353dab0594b09754977f5f71d26fc7fd7840eff557d0fd493d9a49b4abebe6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f67ad34d4cfbf12d0a3dea855cb06e3f5ab77de6c8a8db044c0f0401b59f2e5 = $this->env->getExtension("native_profiler");
        $__internal_3f67ad34d4cfbf12d0a3dea855cb06e3f5ab77de6c8a8db044c0f0401b59f2e5->enter($__internal_3f67ad34d4cfbf12d0a3dea855cb06e3f5ab77de6c8a8db044c0f0401b59f2e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_3f67ad34d4cfbf12d0a3dea855cb06e3f5ab77de6c8a8db044c0f0401b59f2e5->leave($__internal_3f67ad34d4cfbf12d0a3dea855cb06e3f5ab77de6c8a8db044c0f0401b59f2e5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
