<?php

/* :episodes:show.html.twig */
class __TwigTemplate_3538cdda5beaca600cd4498a3f05b56ab9dbc7b70e700ee643c97881bf868829 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":episodes:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1361bb833b15379a5cbbfc9da7f10cef1934ed40d84b6d0ad3d2bb92c972b02 = $this->env->getExtension("native_profiler");
        $__internal_a1361bb833b15379a5cbbfc9da7f10cef1934ed40d84b6d0ad3d2bb92c972b02->enter($__internal_a1361bb833b15379a5cbbfc9da7f10cef1934ed40d84b6d0ad3d2bb92c972b02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":episodes:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a1361bb833b15379a5cbbfc9da7f10cef1934ed40d84b6d0ad3d2bb92c972b02->leave($__internal_a1361bb833b15379a5cbbfc9da7f10cef1934ed40d84b6d0ad3d2bb92c972b02_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_2ca1000b697e23732bf1292d7838adcf2d5f06a77ccd790c7be5bc98e3a90013 = $this->env->getExtension("native_profiler");
        $__internal_2ca1000b697e23732bf1292d7838adcf2d5f06a77ccd790c7be5bc98e3a90013->enter($__internal_2ca1000b697e23732bf1292d7838adcf2d5f06a77ccd790c7be5bc98e3a90013_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Episodes</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Nomepisode</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "nomEpisode", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Resumeepisode</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "resumeEpisode", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dureeepisode</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "dureeEpisode", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Dateepisode</th>
                <td>";
        // line 26
        if ($this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "dateEpisode", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "dateEpisode", array()), "Y-m-d H:i:s"), "html", null, true);
        }
        echo "</td>
            </tr>
            <tr>
                <th>Notemoyenneepisode</th>
                <td>";
        // line 30
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "noteMoyenneEpisode", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Classificationepisode</th>
                <td>";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "classificationEpisode", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Diffusionepisode</th>
                <td>";
        // line 38
        if ($this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "diffusionEpisode", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "diffusionEpisode", array()), "Y-m-d H:i:s"), "html", null, true);
        }
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 45
        echo $this->env->getExtension('routing')->getPath("episodes_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("episodes_edit", array("id" => $this->getAttribute((isset($context["episode"]) ? $context["episode"] : $this->getContext($context, "episode")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 51
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 53
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_2ca1000b697e23732bf1292d7838adcf2d5f06a77ccd790c7be5bc98e3a90013->leave($__internal_2ca1000b697e23732bf1292d7838adcf2d5f06a77ccd790c7be5bc98e3a90013_prof);

    }

    public function getTemplateName()
    {
        return ":episodes:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 53,  123 => 51,  117 => 48,  111 => 45,  99 => 38,  92 => 34,  85 => 30,  76 => 26,  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Episodes</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ episode.id }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Nomepisode</th>*/
/*                 <td>{{ episode.nomEpisode }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Resumeepisode</th>*/
/*                 <td>{{ episode.resumeEpisode }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Dureeepisode</th>*/
/*                 <td>{{ episode.dureeEpisode }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Dateepisode</th>*/
/*                 <td>{% if episode.dateEpisode %}{{ episode.dateEpisode|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Notemoyenneepisode</th>*/
/*                 <td>{{ episode.noteMoyenneEpisode }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Classificationepisode</th>*/
/*                 <td>{{ episode.classificationEpisode }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Diffusionepisode</th>*/
/*                 <td>{% if episode.diffusionEpisode %}{{ episode.diffusionEpisode|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('episodes_index') }}">Back to the list</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('episodes_edit', { 'id': episode.id }) }}">Edit</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Delete">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
