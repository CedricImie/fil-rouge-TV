<?php

/* :user:show.html.twig */
class __TwigTemplate_4f2c301ea42775101a4dca657d2ca9feecc5a6ec3912c0f8a52a1e8d5958754e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":user:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f662aece258848c2762048c8386e48dd7153570e740bfb78fa287cdd45bd937 = $this->env->getExtension("native_profiler");
        $__internal_4f662aece258848c2762048c8386e48dd7153570e740bfb78fa287cdd45bd937->enter($__internal_4f662aece258848c2762048c8386e48dd7153570e740bfb78fa287cdd45bd937_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":user:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4f662aece258848c2762048c8386e48dd7153570e740bfb78fa287cdd45bd937->leave($__internal_4f662aece258848c2762048c8386e48dd7153570e740bfb78fa287cdd45bd937_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_421dc0c61ef8b4d7d774dfad152f8f585686dcdef9871bc28630ce4c4d19074b = $this->env->getExtension("native_profiler");
        $__internal_421dc0c61ef8b4d7d774dfad152f8f585686dcdef9871bc28630ce4c4d19074b->enter($__internal_421dc0c61ef8b4d7d774dfad152f8f585686dcdef9871bc28630ce4c4d19074b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>User</h1>

    <table>
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Pseudoutilisateur</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "pseudoUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Prenomutilisateur</th>
                <td>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "prenomUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Nomutilisateur</th>
                <td>";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "nomUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Adresseemailutilisateur</th>
                <td>";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "adresseEmailUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Datenaissanceutilisateur</th>
                <td>";
        // line 30
        if ($this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "dateNaissanceUtilisateur", array())) {
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "dateNaissanceUtilisateur", array()), "Y-m-d H:i:s"), "html", null, true);
        }
        echo "</td>
            </tr>
            <tr>
                <th>Photoprofilutilisateur</th>
                <td>";
        // line 34
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "photoProfilUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Motdepasseutilisateur</th>
                <td>";
        // line 38
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "motDePasseUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Sexeutilisateur</th>
                <td>";
        // line 42
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "sexeUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Facebookutilisateur</th>
                <td>";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "facebookUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Twitterutilisateur</th>
                <td>";
        // line 50
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "twitterUtilisateur", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 57
        echo $this->env->getExtension('routing')->getPath("user_index");
        echo "\">Back to the list</a>
        </li>
        <li>
            <a href=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_edit", array("id" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "id", array()))), "html", null, true);
        echo "\">Edit</a>
        </li>
        <li>
            ";
        // line 63
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start');
        echo "
                <input type=\"submit\" value=\"Delete\">
            ";
        // line 65
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
        </li>
    </ul>
";
        
        $__internal_421dc0c61ef8b4d7d774dfad152f8f585686dcdef9871bc28630ce4c4d19074b->leave($__internal_421dc0c61ef8b4d7d774dfad152f8f585686dcdef9871bc28630ce4c4d19074b_prof);

    }

    public function getTemplateName()
    {
        return ":user:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 65,  142 => 63,  136 => 60,  130 => 57,  120 => 50,  113 => 46,  106 => 42,  99 => 38,  92 => 34,  83 => 30,  76 => 26,  69 => 22,  62 => 18,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>User</h1>*/
/* */
/*     <table>*/
/*         <tbody>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <td>{{ user.id }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Pseudoutilisateur</th>*/
/*                 <td>{{ user.pseudoUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Prenomutilisateur</th>*/
/*                 <td>{{ user.prenomUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Nomutilisateur</th>*/
/*                 <td>{{ user.nomUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Adresseemailutilisateur</th>*/
/*                 <td>{{ user.adresseEmailUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Datenaissanceutilisateur</th>*/
/*                 <td>{% if user.dateNaissanceUtilisateur %}{{ user.dateNaissanceUtilisateur|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Photoprofilutilisateur</th>*/
/*                 <td>{{ user.photoProfilUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Motdepasseutilisateur</th>*/
/*                 <td>{{ user.motDePasseUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Sexeutilisateur</th>*/
/*                 <td>{{ user.sexeUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Facebookutilisateur</th>*/
/*                 <td>{{ user.facebookUtilisateur }}</td>*/
/*             </tr>*/
/*             <tr>*/
/*                 <th>Twitterutilisateur</th>*/
/*                 <td>{{ user.twitterUtilisateur }}</td>*/
/*             </tr>*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('user_index') }}">Back to the list</a>*/
/*         </li>*/
/*         <li>*/
/*             <a href="{{ path('user_edit', { 'id': user.id }) }}">Edit</a>*/
/*         </li>*/
/*         <li>*/
/*             {{ form_start(delete_form) }}*/
/*                 <input type="submit" value="Delete">*/
/*             {{ form_end(delete_form) }}*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
