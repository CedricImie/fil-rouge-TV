<?php

/* administrateurs/index.html.twig */
class __TwigTemplate_cd1e0c327fb5f62fb6e3cd7120b1c66541708cbb564d3081e14b29015a9ca2bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "administrateurs/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd3a64a0919717f9c73779f67458a7b0c6a70ba5087d36b42caff6b87c587821 = $this->env->getExtension("native_profiler");
        $__internal_dd3a64a0919717f9c73779f67458a7b0c6a70ba5087d36b42caff6b87c587821->enter($__internal_dd3a64a0919717f9c73779f67458a7b0c6a70ba5087d36b42caff6b87c587821_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "administrateurs/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dd3a64a0919717f9c73779f67458a7b0c6a70ba5087d36b42caff6b87c587821->leave($__internal_dd3a64a0919717f9c73779f67458a7b0c6a70ba5087d36b42caff6b87c587821_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_8b4325dde99d1e9499d856f62ea2d69d4719ca93c577f643892a7c6cf3f282cf = $this->env->getExtension("native_profiler");
        $__internal_8b4325dde99d1e9499d856f62ea2d69d4719ca93c577f643892a7c6cf3f282cf->enter($__internal_8b4325dde99d1e9499d856f62ea2d69d4719ca93c577f643892a7c6cf3f282cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Administrateurs list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["administrateurs"]) ? $context["administrateurs"] : $this->getContext($context, "administrateurs")));
        foreach ($context['_seq'] as $context["_key"] => $context["administrateur"]) {
            // line 15
            echo "            <tr>
                <td><a href=\"";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("administrateurs_show", array("id" => $this->getAttribute($context["administrateur"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["administrateur"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("administrateurs_show", array("id" => $this->getAttribute($context["administrateur"], "id", array()))), "html", null, true);
            echo "\">show</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("administrateurs_edit", array("id" => $this->getAttribute($context["administrateur"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['administrateur'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 34
        echo $this->env->getExtension('routing')->getPath("administrateurs_new");
        echo "\">Create a new entry</a>
        </li>
    </ul>
";
        
        $__internal_8b4325dde99d1e9499d856f62ea2d69d4719ca93c577f643892a7c6cf3f282cf->leave($__internal_8b4325dde99d1e9499d856f62ea2d69d4719ca93c577f643892a7c6cf3f282cf_prof);

    }

    public function getTemplateName()
    {
        return "administrateurs/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  93 => 34,  86 => 29,  74 => 23,  68 => 20,  59 => 16,  56 => 15,  52 => 14,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Administrateurs list</h1>*/
/* */
/*     <table>*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <th>Actions</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for administrateur in administrateurs %}*/
/*             <tr>*/
/*                 <td><a href="{{ path('administrateurs_show', { 'id': administrateur.id }) }}">{{ administrateur.id }}</a></td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('administrateurs_show', { 'id': administrateur.id }) }}">show</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('administrateurs_edit', { 'id': administrateur.id }) }}">edit</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('administrateurs_new') }}">Create a new entry</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
