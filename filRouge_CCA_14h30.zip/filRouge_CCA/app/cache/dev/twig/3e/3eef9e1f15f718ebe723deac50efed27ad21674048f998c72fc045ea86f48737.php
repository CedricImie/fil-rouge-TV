<?php

/* series/index.html.twig */
class __TwigTemplate_2b4ea3b36f36a1d9d7572a2bf4b2fe6227b570243342c2a6d8e876c562dbf251 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "series/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e65e142754a8f15df9034cf2cee9a8dd497534b986f55cacce943f501422c069 = $this->env->getExtension("native_profiler");
        $__internal_e65e142754a8f15df9034cf2cee9a8dd497534b986f55cacce943f501422c069->enter($__internal_e65e142754a8f15df9034cf2cee9a8dd497534b986f55cacce943f501422c069_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "series/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e65e142754a8f15df9034cf2cee9a8dd497534b986f55cacce943f501422c069->leave($__internal_e65e142754a8f15df9034cf2cee9a8dd497534b986f55cacce943f501422c069_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_59b5f091526102633ad1339057b29926430feeff738e99ba0bf8b57d4262d249 = $this->env->getExtension("native_profiler");
        $__internal_59b5f091526102633ad1339057b29926430feeff738e99ba0bf8b57d4262d249->enter($__internal_59b5f091526102633ad1339057b29926430feeff738e99ba0bf8b57d4262d249_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "TalkSeries";
        
        $__internal_59b5f091526102633ad1339057b29926430feeff738e99ba0bf8b57d4262d249->leave($__internal_59b5f091526102633ad1339057b29926430feeff738e99ba0bf8b57d4262d249_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_e1e7545b0b03554fa76bf960d6fdc0352f85e334769ee7146e5a6db7630a2455 = $this->env->getExtension("native_profiler");
        $__internal_e1e7545b0b03554fa76bf960d6fdc0352f85e334769ee7146e5a6db7630a2455->enter($__internal_e1e7545b0b03554fa76bf960d6fdc0352f85e334769ee7146e5a6db7630a2455_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
<!-- *** Header *** -->
<div class=\"header\">
  <!-- *** Logo *** -->
  <div class=\"row-H1\">
    <div class=\"logo\">
      <a href=\"http://127.0.0.1:8000\"><img src=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("/images/Logo.jpg"), "html", null, true);
        echo "\" alt=\"Logo du site\" /></a>
    </div>
    <!-- *** Login *** -->
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-2\">
      <div class=\"form-group form-group-sm\">
        <div class=\"login\">
          <input class=\"form-control\" type=\"text\" name=\"login\" placeholder=\"Identifiant\">
        </div>
        <div class=\"password\">
          <input class=\"form-control\" type=\"text\" name=\"password\" placeholder=\"Mot de passe\">
        </div>
      </div>
      <div class=\"btnConnInsc\">
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnConnexion\">Connexion</button>
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnSub\">Inscription</button>
      </div>
    </div>
  </div>
  <!-- *** Language *** -->
  <div class=\"row-H2\">
    <div class=\"col-md-1\">
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnFr\">Fr</button>
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnEn\">En</button>
    </div>
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-1\"></div>
  </div>
</div>
<!-- *** Main *** -->
    <h1>Series list</h1>

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Nomserie</th>
                <th>Posterserie</th>
                <th>Resumeserie</th>
                <th>Datecreationserie</th>
                <th>Notemoyenneserie</th>
                <th>Nbabonneserie</th>
                <th>Castingserie</th>
                <th>Genreserie</th>
                <th>Diffusionserie</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 60
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($context["series"]);
        foreach ($context['_seq'] as $context["_key"] => $context["series"]) {
            // line 61
            echo "            <tr>
                <td><a href=\"";
            // line 62
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("series_show", array("id" => $this->getAttribute($context["series"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "id", array()), "html", null, true);
            echo "</a></td>
                <td>";
            // line 63
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "nomSerie", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 64
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "posterSerie", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "resumeSerie", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 66
            if ($this->getAttribute($context["series"], "dateCreationSerie", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["series"], "dateCreationSerie", array()), "Y-m-d H:i:s"), "html", null, true);
            }
            echo "</td>
                <td>";
            // line 67
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "noteMoyenneSerie", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "nbAbonneSerie", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 69
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "castingSerie", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 70
            echo twig_escape_filter($this->env, $this->getAttribute($context["series"], "genreSerie", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 71
            if ($this->getAttribute($context["series"], "diffusionSerie", array())) {
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["series"], "diffusionSerie", array()), "Y-m-d H:i:s"), "html", null, true);
            }
            echo "</td>
                <td>
                    <ul>
                        <li>
                            <a href=\"";
            // line 75
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("series_show", array("id" => $this->getAttribute($context["series"], "id", array()))), "html", null, true);
            echo "\">show</a>
                        </li>
                        <li>
                            <a href=\"";
            // line 78
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("series_edit", array("id" => $this->getAttribute($context["series"], "id", array()))), "html", null, true);
            echo "\">edit</a>
                        </li>
                    </ul>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['series'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 84
        echo "        </tbody>
    </table>

    <ul>
        <li>
            <a href=\"";
        // line 89
        echo $this->env->getExtension('routing')->getPath("series_new");
        echo "\">Create a new entry</a>
        </li>
    </ul>
<!-- *** Footer *** -->
<div class=\"footer\">
  <div class=\"row-F1\"></div>
  <div class=\"row-F2\">
    <p>Imie</p>
  </div>
  <div class=\"row-F3\"></div>
</div>
";
        
        $__internal_e1e7545b0b03554fa76bf960d6fdc0352f85e334769ee7146e5a6db7630a2455->leave($__internal_e1e7545b0b03554fa76bf960d6fdc0352f85e334769ee7146e5a6db7630a2455_prof);

    }

    public function getTemplateName()
    {
        return "series/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 89,  187 => 84,  175 => 78,  169 => 75,  160 => 71,  156 => 70,  152 => 69,  148 => 68,  144 => 67,  138 => 66,  134 => 65,  130 => 64,  126 => 63,  120 => 62,  117 => 61,  113 => 60,  61 => 11,  53 => 5,  47 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block title %}TalkSeries{% endblock %}*/
/* {% block body %}*/
/* */
/* <!-- *** Header *** -->*/
/* <div class="header">*/
/*   <!-- *** Logo *** -->*/
/*   <div class="row-H1">*/
/*     <div class="logo">*/
/*       <a href="http://127.0.0.1:8000"><img src="{{ asset ('/images/Logo.jpg') }}" alt="Logo du site" /></a>*/
/*     </div>*/
/*     <!-- *** Login *** -->*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-2">*/
/*       <div class="form-group form-group-sm">*/
/*         <div class="login">*/
/*           <input class="form-control" type="text" name="login" placeholder="Identifiant">*/
/*         </div>*/
/*         <div class="password">*/
/*           <input class="form-control" type="text" name="password" placeholder="Mot de passe">*/
/*         </div>*/
/*       </div>*/
/*       <div class="btnConnInsc">*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnConnexion">Connexion</button>*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnSub">Inscription</button>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/*   <!-- *** Language *** -->*/
/*   <div class="row-H2">*/
/*     <div class="col-md-1">*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnFr">Fr</button>*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnEn">En</button>*/
/*     </div>*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-1"></div>*/
/*   </div>*/
/* </div>*/
/* <!-- *** Main *** -->*/
/*     <h1>Series list</h1>*/
/* */
/*     <table>*/
/*         <thead>*/
/*             <tr>*/
/*                 <th>Id</th>*/
/*                 <th>Nomserie</th>*/
/*                 <th>Posterserie</th>*/
/*                 <th>Resumeserie</th>*/
/*                 <th>Datecreationserie</th>*/
/*                 <th>Notemoyenneserie</th>*/
/*                 <th>Nbabonneserie</th>*/
/*                 <th>Castingserie</th>*/
/*                 <th>Genreserie</th>*/
/*                 <th>Diffusionserie</th>*/
/*                 <th>Actions</th>*/
/*             </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*         {% for series in series %}*/
/*             <tr>*/
/*                 <td><a href="{{ path('series_show', { 'id': series.id }) }}">{{ series.id }}</a></td>*/
/*                 <td>{{ series.nomSerie }}</td>*/
/*                 <td>{{ series.posterSerie }}</td>*/
/*                 <td>{{ series.resumeSerie }}</td>*/
/*                 <td>{% if series.dateCreationSerie %}{{ series.dateCreationSerie|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*                 <td>{{ series.noteMoyenneSerie }}</td>*/
/*                 <td>{{ series.nbAbonneSerie }}</td>*/
/*                 <td>{{ series.castingSerie }}</td>*/
/*                 <td>{{ series.genreSerie }}</td>*/
/*                 <td>{% if series.diffusionSerie %}{{ series.diffusionSerie|date('Y-m-d H:i:s') }}{% endif %}</td>*/
/*                 <td>*/
/*                     <ul>*/
/*                         <li>*/
/*                             <a href="{{ path('series_show', { 'id': series.id }) }}">show</a>*/
/*                         </li>*/
/*                         <li>*/
/*                             <a href="{{ path('series_edit', { 'id': series.id }) }}">edit</a>*/
/*                         </li>*/
/*                     </ul>*/
/*                 </td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*         </tbody>*/
/*     </table>*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('series_new') }}">Create a new entry</a>*/
/*         </li>*/
/*     </ul>*/
/* <!-- *** Footer *** -->*/
/* <div class="footer">*/
/*   <div class="row-F1"></div>*/
/*   <div class="row-F2">*/
/*     <p>Imie</p>*/
/*   </div>*/
/*   <div class="row-F3"></div>*/
/* </div>*/
/* {% endblock %}*/
/* */
