<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_cdaf06aecad3f5f158d903b49cb87e56df5b6d0e1285dbf0e4681fff4ebb5ce4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d2b8468ad67e9b311f020ea7df2828df1ed645e791599429da22d7b0d6cfab53 = $this->env->getExtension("native_profiler");
        $__internal_d2b8468ad67e9b311f020ea7df2828df1ed645e791599429da22d7b0d6cfab53->enter($__internal_d2b8468ad67e9b311f020ea7df2828df1ed645e791599429da22d7b0d6cfab53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_d2b8468ad67e9b311f020ea7df2828df1ed645e791599429da22d7b0d6cfab53->leave($__internal_d2b8468ad67e9b311f020ea7df2828df1ed645e791599429da22d7b0d6cfab53_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
