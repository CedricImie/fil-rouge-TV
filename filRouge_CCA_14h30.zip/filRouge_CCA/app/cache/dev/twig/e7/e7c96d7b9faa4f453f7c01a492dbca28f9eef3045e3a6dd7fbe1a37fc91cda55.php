<?php

/* MovieBundle:Default:index.html.twig */
class __TwigTemplate_5b438e015e424a32d8d0ab72be3c8324d631d10008d819fc287148b000378cc6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "MovieBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ef7e3ef6b2c15c0c42d6a822f54dda03a5d47d8bae2672dd1b2986d7f975ce2a = $this->env->getExtension("native_profiler");
        $__internal_ef7e3ef6b2c15c0c42d6a822f54dda03a5d47d8bae2672dd1b2986d7f975ce2a->enter($__internal_ef7e3ef6b2c15c0c42d6a822f54dda03a5d47d8bae2672dd1b2986d7f975ce2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "MovieBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ef7e3ef6b2c15c0c42d6a822f54dda03a5d47d8bae2672dd1b2986d7f975ce2a->leave($__internal_ef7e3ef6b2c15c0c42d6a822f54dda03a5d47d8bae2672dd1b2986d7f975ce2a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_cc23d3c93fb67c2a011c10d9858acebf370793227e95cf142eb39abc92f7cb79 = $this->env->getExtension("native_profiler");
        $__internal_cc23d3c93fb67c2a011c10d9858acebf370793227e95cf142eb39abc92f7cb79->enter($__internal_cc23d3c93fb67c2a011c10d9858acebf370793227e95cf142eb39abc92f7cb79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "TalkSeries";
        
        $__internal_cc23d3c93fb67c2a011c10d9858acebf370793227e95cf142eb39abc92f7cb79->leave($__internal_cc23d3c93fb67c2a011c10d9858acebf370793227e95cf142eb39abc92f7cb79_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_8358f625ca4204179446f341aaf97985364c01bb83a0eccda0923638b122008e = $this->env->getExtension("native_profiler");
        $__internal_8358f625ca4204179446f341aaf97985364c01bb83a0eccda0923638b122008e->enter($__internal_8358f625ca4204179446f341aaf97985364c01bb83a0eccda0923638b122008e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "
<!-- *** Header *** -->
<div class=\"header\">
  <!-- *** Logo *** -->
  <div class=\"row-H1\">
    <div class=\"logo\">
      <img src=\"images/Logo.jpg\" alt=\"Logo du site\" />
    </div>
    <!-- *** Login *** -->
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-2\">
      <div class=\"form-group form-group-sm\">
        <div class=\"login\">
          <input class=\"form-control\" type=\"text\" name=\"login\" placeholder=\"Identifiant\">
        </div>
        <div class=\"password\">
          <input class=\"form-control\" type=\"text\" name=\"password\" placeholder=\"Mot de passe\">
        </div>
      </div>
      <div class=\"btnConnInsc\">
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnConnexion\">Connexion</button>
        <button class=\"btn btn-default btn-sm\" type=\"button\" name=\"btnSub\">Inscription</button>
      </div>
    </div>
  </div>
  <!-- *** Language *** -->
  <div class=\"row-H2\">
    <div class=\"col-md-1\">
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnFr\">Fr</button>
      <button class=\"btn btn-default btn-xs\" type=\"button\" name=\"btnEn\">En</button>
    </div>
    <div class=\"col-md-10\"></div>
    <div class=\"col-md-1\"></div>
  </div>
</div>
<!-- *** Main *** -->
<div class=\"main\">
  <div class=\"row-M1\">
    <div class=\"col-md-4 col-md-offset-4\">
      <input class=\"form-control input-lg\" type=\"text\" name=\"search\" placeholder=\"Recherche\">
    </div>
  </div>
  <div class=\"row-M2\">
    <div class=\"btnSeriesForum\">
      <div class=\"col-md-8 col-md-offset-2\">
        <a href=\"http://127.0.0.1:8000/series/\" class=\"btn btn-default btn-lg\" style=\"display: inline-block; width: 49%\">Séries</a>
        <a href=\"#\" class=\"btn btn-default btn-lg\" style=\"display: inline-block; width: 49%\">Forum</a>
      </div>
    </div>
  </div>
    <div class=\"carouselCommentaires\">
      <div class=\"col-md-7\">
        <div class=\"carousel\">
<!-- *** Carousel start *** -->
          <div id=\"myCarousel\" class=\"carousel slide\" data-ride=\"carousel\">
            <!-- Indicators -->
            <ol class=\"carousel-indicators\">
              <li data-target=\"#myCarousel\" data-slide-to=\"0\" class=\"active\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"1\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"2\"></li>
              <li data-target=\"#myCarousel\" data-slide-to=\"3\"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class=\"carousel-inner\" role=\"listbox\">
              <div class=\"item active\">
                <img src=\"images/01.jpg\" alt=\"image01\" width=\"460\" height=\"345\">
              </div>

              <div class=\"item\">
                <img src=\"images/02.jpg\" alt=\"image02\" width=\"460\" height=\"345\">
              </div>

              <div class=\"item\">
                <img src=\"images/03.jpg\" alt=\"image03\" width=\"460\" height=\"345\">
              </div>

              <div class=\"item\">
                <img src=\"images/04.jpg\" alt=\"image04\" width=\"460\" height=\"345\">
              </div>
            </div>

            <!-- Left and right controls -->
            <a class=\"left carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"prev\">
              <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
              <span class=\"sr-only\">Previous</span>
            </a>
            <a class=\"right carousel-control\" href=\"#myCarousel\" role=\"button\" data-slide=\"next\">
              <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden=\"true\"></span>
              <span class=\"sr-only\">Next</span>
            </a>
          </div>
<!-- *** Carousel end *** -->
        </div>
      </div>
      <div class=\"col-md-5\">
        <div class=\"commentaires\">
          Commentaires
        </div>
      </div>
    </div>
</div>
<!-- *** Footer *** -->
<div class=\"footer\">
  <div class=\"row-F1\"></div>
  <div class=\"row-F2\">
    <p>Imie</p>
  </div>
  <div class=\"row-F3\"></div>
</div>
";
        
        $__internal_8358f625ca4204179446f341aaf97985364c01bb83a0eccda0923638b122008e->leave($__internal_8358f625ca4204179446f341aaf97985364c01bb83a0eccda0923638b122008e_prof);

    }

    public function getTemplateName()
    {
        return "MovieBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 5,  47 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends '::base.html.twig' %}*/
/* */
/* {% block title %}TalkSeries{% endblock %}*/
/* {% block body %}*/
/* */
/* <!-- *** Header *** -->*/
/* <div class="header">*/
/*   <!-- *** Logo *** -->*/
/*   <div class="row-H1">*/
/*     <div class="logo">*/
/*       <img src="images/Logo.jpg" alt="Logo du site" />*/
/*     </div>*/
/*     <!-- *** Login *** -->*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-2">*/
/*       <div class="form-group form-group-sm">*/
/*         <div class="login">*/
/*           <input class="form-control" type="text" name="login" placeholder="Identifiant">*/
/*         </div>*/
/*         <div class="password">*/
/*           <input class="form-control" type="text" name="password" placeholder="Mot de passe">*/
/*         </div>*/
/*       </div>*/
/*       <div class="btnConnInsc">*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnConnexion">Connexion</button>*/
/*         <button class="btn btn-default btn-sm" type="button" name="btnSub">Inscription</button>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/*   <!-- *** Language *** -->*/
/*   <div class="row-H2">*/
/*     <div class="col-md-1">*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnFr">Fr</button>*/
/*       <button class="btn btn-default btn-xs" type="button" name="btnEn">En</button>*/
/*     </div>*/
/*     <div class="col-md-10"></div>*/
/*     <div class="col-md-1"></div>*/
/*   </div>*/
/* </div>*/
/* <!-- *** Main *** -->*/
/* <div class="main">*/
/*   <div class="row-M1">*/
/*     <div class="col-md-4 col-md-offset-4">*/
/*       <input class="form-control input-lg" type="text" name="search" placeholder="Recherche">*/
/*     </div>*/
/*   </div>*/
/*   <div class="row-M2">*/
/*     <div class="btnSeriesForum">*/
/*       <div class="col-md-8 col-md-offset-2">*/
/*         <a href="http://127.0.0.1:8000/series/" class="btn btn-default btn-lg" style="display: inline-block; width: 49%">Séries</a>*/
/*         <a href="#" class="btn btn-default btn-lg" style="display: inline-block; width: 49%">Forum</a>*/
/*       </div>*/
/*     </div>*/
/*   </div>*/
/*     <div class="carouselCommentaires">*/
/*       <div class="col-md-7">*/
/*         <div class="carousel">*/
/* <!-- *** Carousel start *** -->*/
/*           <div id="myCarousel" class="carousel slide" data-ride="carousel">*/
/*             <!-- Indicators -->*/
/*             <ol class="carousel-indicators">*/
/*               <li data-target="#myCarousel" data-slide-to="0" class="active"></li>*/
/*               <li data-target="#myCarousel" data-slide-to="1"></li>*/
/*               <li data-target="#myCarousel" data-slide-to="2"></li>*/
/*               <li data-target="#myCarousel" data-slide-to="3"></li>*/
/*             </ol>*/
/* */
/*             <!-- Wrapper for slides -->*/
/*             <div class="carousel-inner" role="listbox">*/
/*               <div class="item active">*/
/*                 <img src="images/01.jpg" alt="image01" width="460" height="345">*/
/*               </div>*/
/* */
/*               <div class="item">*/
/*                 <img src="images/02.jpg" alt="image02" width="460" height="345">*/
/*               </div>*/
/* */
/*               <div class="item">*/
/*                 <img src="images/03.jpg" alt="image03" width="460" height="345">*/
/*               </div>*/
/* */
/*               <div class="item">*/
/*                 <img src="images/04.jpg" alt="image04" width="460" height="345">*/
/*               </div>*/
/*             </div>*/
/* */
/*             <!-- Left and right controls -->*/
/*             <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">*/
/*               <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>*/
/*               <span class="sr-only">Previous</span>*/
/*             </a>*/
/*             <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">*/
/*               <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>*/
/*               <span class="sr-only">Next</span>*/
/*             </a>*/
/*           </div>*/
/* <!-- *** Carousel end *** -->*/
/*         </div>*/
/*       </div>*/
/*       <div class="col-md-5">*/
/*         <div class="commentaires">*/
/*           Commentaires*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/* </div>*/
/* <!-- *** Footer *** -->*/
/* <div class="footer">*/
/*   <div class="row-F1"></div>*/
/*   <div class="row-F2">*/
/*     <p>Imie</p>*/
/*   </div>*/
/*   <div class="row-F3"></div>*/
/* </div>*/
/* {% endblock %}*/
/* */
