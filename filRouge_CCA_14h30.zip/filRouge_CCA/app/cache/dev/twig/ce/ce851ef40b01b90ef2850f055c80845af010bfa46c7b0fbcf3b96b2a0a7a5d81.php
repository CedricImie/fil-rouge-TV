<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_13e28a5381b9d15d54c1aea4184bc5e1608de70b6520d99c5b3ff133190bc183 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c96ac317233482371eb5312998455a38c695a8dfcc31862d1b986bdd26df8fe5 = $this->env->getExtension("native_profiler");
        $__internal_c96ac317233482371eb5312998455a38c695a8dfcc31862d1b986bdd26df8fe5->enter($__internal_c96ac317233482371eb5312998455a38c695a8dfcc31862d1b986bdd26df8fe5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_c96ac317233482371eb5312998455a38c695a8dfcc31862d1b986bdd26df8fe5->leave($__internal_c96ac317233482371eb5312998455a38c695a8dfcc31862d1b986bdd26df8fe5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
