<?php

/* FOSUserBundle:Registration:checkEmail.html.twig */
class __TwigTemplate_ae212b840db509e6e4967bcb4c295d3adb17f9c7d9c305e5c112442f1ea32d43 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_697d6e84587082956f73f825780d448bbfce150ebb644e0e9a0a22ad395f3f57 = $this->env->getExtension("native_profiler");
        $__internal_697d6e84587082956f73f825780d448bbfce150ebb644e0e9a0a22ad395f3f57->enter($__internal_697d6e84587082956f73f825780d448bbfce150ebb644e0e9a0a22ad395f3f57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_697d6e84587082956f73f825780d448bbfce150ebb644e0e9a0a22ad395f3f57->leave($__internal_697d6e84587082956f73f825780d448bbfce150ebb644e0e9a0a22ad395f3f57_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ded5610fc303b62605c7141131bc667b3fbf652f65571debeecbea299a505282 = $this->env->getExtension("native_profiler");
        $__internal_ded5610fc303b62605c7141131bc667b3fbf652f65571debeecbea299a505282->enter($__internal_ded5610fc303b62605c7141131bc667b3fbf652f65571debeecbea299a505282_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_ded5610fc303b62605c7141131bc667b3fbf652f65571debeecbea299a505282->leave($__internal_ded5610fc303b62605c7141131bc667b3fbf652f65571debeecbea299a505282_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
