<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_6c018ad306e5c3d984ce6c324520b77a7de7aceaa6288b7915006034df9e303e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8a58fae14a1ea25942bad339c31b782141a066a956fc8b300adf457e3de3286a = $this->env->getExtension("native_profiler");
        $__internal_8a58fae14a1ea25942bad339c31b782141a066a956fc8b300adf457e3de3286a->enter($__internal_8a58fae14a1ea25942bad339c31b782141a066a956fc8b300adf457e3de3286a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_8a58fae14a1ea25942bad339c31b782141a066a956fc8b300adf457e3de3286a->leave($__internal_8a58fae14a1ea25942bad339c31b782141a066a956fc8b300adf457e3de3286a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
