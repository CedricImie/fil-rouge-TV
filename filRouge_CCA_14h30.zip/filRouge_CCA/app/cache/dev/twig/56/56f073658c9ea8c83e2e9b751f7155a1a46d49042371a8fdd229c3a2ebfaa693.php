<?php

/* :administrateurs:new.html.twig */
class __TwigTemplate_391ca5402285c526790cf3c314c2121098d6fe75a9e59bc5ba21e4dbf7275db5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":administrateurs:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c15ede7052fdde3ca2e3a3142882f4e0b6c6d426bef3303474c99279ae7ad838 = $this->env->getExtension("native_profiler");
        $__internal_c15ede7052fdde3ca2e3a3142882f4e0b6c6d426bef3303474c99279ae7ad838->enter($__internal_c15ede7052fdde3ca2e3a3142882f4e0b6c6d426bef3303474c99279ae7ad838_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":administrateurs:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c15ede7052fdde3ca2e3a3142882f4e0b6c6d426bef3303474c99279ae7ad838->leave($__internal_c15ede7052fdde3ca2e3a3142882f4e0b6c6d426bef3303474c99279ae7ad838_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_141fc07676b3d10605ce197419be351c5d54540456e26b7d639c9d01b5398a16 = $this->env->getExtension("native_profiler");
        $__internal_141fc07676b3d10605ce197419be351c5d54540456e26b7d639c9d01b5398a16->enter($__internal_141fc07676b3d10605ce197419be351c5d54540456e26b7d639c9d01b5398a16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <h1>Administrateurs creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
        <input type=\"submit\" value=\"Create\" />
    ";
        // line 9
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "

    <ul>
        <li>
            <a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("administrateurs_index");
        echo "\">Back to the list</a>
        </li>
    </ul>
";
        
        $__internal_141fc07676b3d10605ce197419be351c5d54540456e26b7d639c9d01b5398a16->leave($__internal_141fc07676b3d10605ce197419be351c5d54540456e26b7d639c9d01b5398a16_prof);

    }

    public function getTemplateName()
    {
        return ":administrateurs:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 13,  53 => 9,  48 => 7,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block body %}*/
/*     <h1>Administrateurs creation</h1>*/
/* */
/*     {{ form_start(form) }}*/
/*         {{ form_widget(form) }}*/
/*         <input type="submit" value="Create" />*/
/*     {{ form_end(form) }}*/
/* */
/*     <ul>*/
/*         <li>*/
/*             <a href="{{ path('administrateurs_index') }}">Back to the list</a>*/
/*         </li>*/
/*     </ul>*/
/* {% endblock %}*/
/* */
