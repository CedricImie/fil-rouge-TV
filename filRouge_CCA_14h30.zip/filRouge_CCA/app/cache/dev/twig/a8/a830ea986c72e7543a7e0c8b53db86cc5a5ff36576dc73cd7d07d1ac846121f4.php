<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_4c00dcafea22e25902859ebd66a84f587e8cfe8b0b9f9a56622abf7bc34e437a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_acb4bc5455d5bb5dc658d83a0ece29054fcaf7a31c6d65694d1a30cff1065a0d = $this->env->getExtension("native_profiler");
        $__internal_acb4bc5455d5bb5dc658d83a0ece29054fcaf7a31c6d65694d1a30cff1065a0d->enter($__internal_acb4bc5455d5bb5dc658d83a0ece29054fcaf7a31c6d65694d1a30cff1065a0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_acb4bc5455d5bb5dc658d83a0ece29054fcaf7a31c6d65694d1a30cff1065a0d->leave($__internal_acb4bc5455d5bb5dc658d83a0ece29054fcaf7a31c6d65694d1a30cff1065a0d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
