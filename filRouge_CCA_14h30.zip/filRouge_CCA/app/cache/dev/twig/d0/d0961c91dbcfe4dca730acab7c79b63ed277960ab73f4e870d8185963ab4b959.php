<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_09eb0fd8b55364c0ce0306cdab67706d8ecc34acdf5ce4b1a640c7a178ef58e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_def614b6f0c4573d904ff3d2e6505bf2eca100b06416fcbf5af43d5bf945ef0a = $this->env->getExtension("native_profiler");
        $__internal_def614b6f0c4573d904ff3d2e6505bf2eca100b06416fcbf5af43d5bf945ef0a->enter($__internal_def614b6f0c4573d904ff3d2e6505bf2eca100b06416fcbf5af43d5bf945ef0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_def614b6f0c4573d904ff3d2e6505bf2eca100b06416fcbf5af43d5bf945ef0a->leave($__internal_def614b6f0c4573d904ff3d2e6505bf2eca100b06416fcbf5af43d5bf945ef0a_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_e81e3a435cebe8ca5c3adb62c2f761f2fb59a906fae8f59fcd8b2d5d2a6e6d28 = $this->env->getExtension("native_profiler");
        $__internal_e81e3a435cebe8ca5c3adb62c2f761f2fb59a906fae8f59fcd8b2d5d2a6e6d28->enter($__internal_e81e3a435cebe8ca5c3adb62c2f761f2fb59a906fae8f59fcd8b2d5d2a6e6d28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_e81e3a435cebe8ca5c3adb62c2f761f2fb59a906fae8f59fcd8b2d5d2a6e6d28->leave($__internal_e81e3a435cebe8ca5c3adb62c2f761f2fb59a906fae8f59fcd8b2d5d2a6e6d28_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_81ca37d5f55f16e6da07b9e2114fb94e65e118a685a5cb4f80eda47d4bcd39ef = $this->env->getExtension("native_profiler");
        $__internal_81ca37d5f55f16e6da07b9e2114fb94e65e118a685a5cb4f80eda47d4bcd39ef->enter($__internal_81ca37d5f55f16e6da07b9e2114fb94e65e118a685a5cb4f80eda47d4bcd39ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_81ca37d5f55f16e6da07b9e2114fb94e65e118a685a5cb4f80eda47d4bcd39ef->leave($__internal_81ca37d5f55f16e6da07b9e2114fb94e65e118a685a5cb4f80eda47d4bcd39ef_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ac1b5b74013fa583046f756380dab71d6f5932ae23699e7d2540f3b1f68b948e = $this->env->getExtension("native_profiler");
        $__internal_ac1b5b74013fa583046f756380dab71d6f5932ae23699e7d2540f3b1f68b948e->enter($__internal_ac1b5b74013fa583046f756380dab71d6f5932ae23699e7d2540f3b1f68b948e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_ac1b5b74013fa583046f756380dab71d6f5932ae23699e7d2540f3b1f68b948e->leave($__internal_ac1b5b74013fa583046f756380dab71d6f5932ae23699e7d2540f3b1f68b948e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
