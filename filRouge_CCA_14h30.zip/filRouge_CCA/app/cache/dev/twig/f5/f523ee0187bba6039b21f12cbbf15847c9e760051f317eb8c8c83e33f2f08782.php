<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_65019ae71ac63c1dd3768083dc23c6581d5a45667ae9c1270ebc91dff1e2b8cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a148254713f61c29aca0c8ee3aeda18941f6363d3228b5857d52195d8035f9d3 = $this->env->getExtension("native_profiler");
        $__internal_a148254713f61c29aca0c8ee3aeda18941f6363d3228b5857d52195d8035f9d3->enter($__internal_a148254713f61c29aca0c8ee3aeda18941f6363d3228b5857d52195d8035f9d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_a148254713f61c29aca0c8ee3aeda18941f6363d3228b5857d52195d8035f9d3->leave($__internal_a148254713f61c29aca0c8ee3aeda18941f6363d3228b5857d52195d8035f9d3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
