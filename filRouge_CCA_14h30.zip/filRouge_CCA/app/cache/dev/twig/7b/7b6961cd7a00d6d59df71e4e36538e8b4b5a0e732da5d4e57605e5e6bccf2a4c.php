<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_97f61295dd38a24d8128f8deec0bf6c1bedf2134eb969325a3f180c4bd67f6d2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aa13721a00ea08794ba640ecc1c514bfba2b381c6d837a7d7eb93f99969384cd = $this->env->getExtension("native_profiler");
        $__internal_aa13721a00ea08794ba640ecc1c514bfba2b381c6d837a7d7eb93f99969384cd->enter($__internal_aa13721a00ea08794ba640ecc1c514bfba2b381c6d837a7d7eb93f99969384cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aa13721a00ea08794ba640ecc1c514bfba2b381c6d837a7d7eb93f99969384cd->leave($__internal_aa13721a00ea08794ba640ecc1c514bfba2b381c6d837a7d7eb93f99969384cd_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_656de30f785fd16cfe8b12bd976af4e147837271adea7d396812be30fce1bbe2 = $this->env->getExtension("native_profiler");
        $__internal_656de30f785fd16cfe8b12bd976af4e147837271adea7d396812be30fce1bbe2->enter($__internal_656de30f785fd16cfe8b12bd976af4e147837271adea7d396812be30fce1bbe2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_656de30f785fd16cfe8b12bd976af4e147837271adea7d396812be30fce1bbe2->leave($__internal_656de30f785fd16cfe8b12bd976af4e147837271adea7d396812be30fce1bbe2_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
