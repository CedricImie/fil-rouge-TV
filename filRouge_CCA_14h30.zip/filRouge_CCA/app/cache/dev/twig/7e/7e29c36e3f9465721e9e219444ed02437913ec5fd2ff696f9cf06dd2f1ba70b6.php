<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_c3725d0b88a48fcaff271c85b0f96d029c9f9075e260e1fe348b94007f5255ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d86d407b1221c50a158e212f1a509cd58c3bf0608db3bf48bda4985b764b38ee = $this->env->getExtension("native_profiler");
        $__internal_d86d407b1221c50a158e212f1a509cd58c3bf0608db3bf48bda4985b764b38ee->enter($__internal_d86d407b1221c50a158e212f1a509cd58c3bf0608db3bf48bda4985b764b38ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d86d407b1221c50a158e212f1a509cd58c3bf0608db3bf48bda4985b764b38ee->leave($__internal_d86d407b1221c50a158e212f1a509cd58c3bf0608db3bf48bda4985b764b38ee_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_94d2b5eedcfe4e03c5edd5ea6f0c5b03a5a8137cf0bcceb3d26f54fd7f8a5e9a = $this->env->getExtension("native_profiler");
        $__internal_94d2b5eedcfe4e03c5edd5ea6f0c5b03a5a8137cf0bcceb3d26f54fd7f8a5e9a->enter($__internal_94d2b5eedcfe4e03c5edd5ea6f0c5b03a5a8137cf0bcceb3d26f54fd7f8a5e9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_94d2b5eedcfe4e03c5edd5ea6f0c5b03a5a8137cf0bcceb3d26f54fd7f8a5e9a->leave($__internal_94d2b5eedcfe4e03c5edd5ea6f0c5b03a5a8137cf0bcceb3d26f54fd7f8a5e9a_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_77fb57f7c14e82382315851fbec003355b038cfdc6592508e3051eae080e2bd7 = $this->env->getExtension("native_profiler");
        $__internal_77fb57f7c14e82382315851fbec003355b038cfdc6592508e3051eae080e2bd7->enter($__internal_77fb57f7c14e82382315851fbec003355b038cfdc6592508e3051eae080e2bd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_77fb57f7c14e82382315851fbec003355b038cfdc6592508e3051eae080e2bd7->leave($__internal_77fb57f7c14e82382315851fbec003355b038cfdc6592508e3051eae080e2bd7_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_cd821213c287dfca361c447c82672d789989f1016fc48e8358031e6587c15510 = $this->env->getExtension("native_profiler");
        $__internal_cd821213c287dfca361c447c82672d789989f1016fc48e8358031e6587c15510->enter($__internal_cd821213c287dfca361c447c82672d789989f1016fc48e8358031e6587c15510_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_cd821213c287dfca361c447c82672d789989f1016fc48e8358031e6587c15510->leave($__internal_cd821213c287dfca361c447c82672d789989f1016fc48e8358031e6587c15510_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     <link href="{{ absolute_url(asset('bundles/framework/css/exception.css')) }}" rel="stylesheet" type="text/css" media="all" />*/
/* {% endblock %}*/
/* */
/* {% block title %}*/
/*     {{ exception.message }} ({{ status_code }} {{ status_text }})*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% include '@Twig/Exception/exception.html.twig' %}*/
/* {% endblock %}*/
/* */
