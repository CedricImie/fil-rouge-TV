<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_f65c1a8a505d459421be223749bc940751c12d2c6cbd6524b38163b5d48afcd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6df595df9fa0a70d09c5d993d324d74159ce68ab004013f059043edf1f1ffd13 = $this->env->getExtension("native_profiler");
        $__internal_6df595df9fa0a70d09c5d993d324d74159ce68ab004013f059043edf1f1ffd13->enter($__internal_6df595df9fa0a70d09c5d993d324d74159ce68ab004013f059043edf1f1ffd13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_6df595df9fa0a70d09c5d993d324d74159ce68ab004013f059043edf1f1ffd13->leave($__internal_6df595df9fa0a70d09c5d993d324d74159ce68ab004013f059043edf1f1ffd13_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
