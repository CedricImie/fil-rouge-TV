<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_2257d82c5ded2cbbf1f8da522da0230f8d46911effa154bfbc3cf7f56995a66a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2768c1211df1a996c60a4d16117ac8869e76e3b9cd0af2a857f75c8ba7559b6d = $this->env->getExtension("native_profiler");
        $__internal_2768c1211df1a996c60a4d16117ac8869e76e3b9cd0af2a857f75c8ba7559b6d->enter($__internal_2768c1211df1a996c60a4d16117ac8869e76e3b9cd0af2a857f75c8ba7559b6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2768c1211df1a996c60a4d16117ac8869e76e3b9cd0af2a857f75c8ba7559b6d->leave($__internal_2768c1211df1a996c60a4d16117ac8869e76e3b9cd0af2a857f75c8ba7559b6d_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_1456410111ca42c86826146628c1d46303761d7356c4b7cf7adb4d15b4e305f1 = $this->env->getExtension("native_profiler");
        $__internal_1456410111ca42c86826146628c1d46303761d7356c4b7cf7adb4d15b4e305f1->enter($__internal_1456410111ca42c86826146628c1d46303761d7356c4b7cf7adb4d15b4e305f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_1456410111ca42c86826146628c1d46303761d7356c4b7cf7adb4d15b4e305f1->leave($__internal_1456410111ca42c86826146628c1d46303761d7356c4b7cf7adb4d15b4e305f1_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
