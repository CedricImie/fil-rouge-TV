<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_e1c4fbbdf1a43df9143ee63c4b5fb40e766610574d57af57533aab44d5560787 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5d175972eecba127437c0830419d31770653b76c4f46ebfe1dda1eb18c1c1cbe = $this->env->getExtension("native_profiler");
        $__internal_5d175972eecba127437c0830419d31770653b76c4f46ebfe1dda1eb18c1c1cbe->enter($__internal_5d175972eecba127437c0830419d31770653b76c4f46ebfe1dda1eb18c1c1cbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_5d175972eecba127437c0830419d31770653b76c4f46ebfe1dda1eb18c1c1cbe->leave($__internal_5d175972eecba127437c0830419d31770653b76c4f46ebfe1dda1eb18c1c1cbe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
